// =============================================
// ORDER BUSINESS - SUPABASE HOOKS
// Tüm veri operasyonları için hooks
// =============================================

import { useState, useEffect, useCallback } from 'react';
import { supabase, subscribeToTable } from '@/lib/supabase';
import type {
  Venue,
  Table,
  Category,
  Product,
  Order,
  Reservation,
  Staff,
  StockItem,
  Customer,
  Coupon,
  Shift,
} from '@/types/database';

// =============================================
// GENERIC FETCH HOOK
// =============================================
interface UseFetchOptions {
  enabled?: boolean;
  realtime?: boolean;
}

function useFetch<T>(
  tableName: string,
  venueId: string | null,
  options: UseFetchOptions = {}
) {
  const { enabled = true, realtime = false } = options;
  const [data, setData] = useState<T[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    if (!venueId || !enabled) {
      setData([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const { data: result, error: fetchError } = await supabase
        .from(tableName)
        .select('*')
        .eq('venue_id', venueId)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setData((result as T[]) || []);
    } catch (err: any) {
      setError(err.message || 'Veri yüklenirken hata oluştu');
      console.error(`${tableName} fetch error:`, err);
    } finally {
      setIsLoading(false);
    }
  }, [tableName, venueId, enabled]);

  useEffect(() => {
    fetch();

    // Real-time subscription
    if (realtime && venueId) {
      const unsubscribe = subscribeToTable(tableName, venueId, (payload) => {
        if (payload.eventType === 'INSERT') {
          setData((prev) => [payload.new as T, ...prev]);
        } else if (payload.eventType === 'UPDATE') {
          setData((prev) =>
            prev.map((item: any) =>
              item.id === payload.new.id ? payload.new : item
            )
          );
        } else if (payload.eventType === 'DELETE') {
          setData((prev) =>
            prev.filter((item: any) => item.id !== payload.old.id)
          );
        }
      });

      return unsubscribe;
    }
  }, [fetch, realtime, venueId, tableName]);

  return { data, isLoading, error, refetch: fetch };
}

// =============================================
// TABLES HOOK
// =============================================
export function useTables(venueId: string | null) {
  const { data, isLoading, error, refetch } = useFetch<Table>(
    'tables',
    venueId,
    { realtime: true }
  );

  const createTable = async (table: Omit<Table, 'id' | 'created_at'>) => {
    const { data: newTable, error } = await supabase
      .from('tables')
      .insert(table)
      .select()
      .single();

    if (error) throw error;
    return newTable;
  };

  const updateTable = async (id: string, updates: Partial<Table>) => {
    const { data: updated, error } = await supabase
      .from('tables')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return updated;
  };

  const deleteTable = async (id: string) => {
    const { error } = await supabase.from('tables').delete().eq('id', id);
    if (error) throw error;
  };

  // Stats hesapla
  const stats = {
    total: data.length,
    available: data.filter((t) => t.status === 'available').length,
    occupied: data.filter((t) => t.status === 'occupied').length,
    reserved: data.filter((t) => t.status === 'reserved').length,
    cleaning: data.filter((t) => t.status === 'cleaning').length,
  };

  // Bölümlere göre grupla
  const sections = [...new Set(data.map((t) => t.section).filter(Boolean))];
  const tablesBySection = sections.reduce((acc, section) => {
    acc[section!] = data.filter((t) => t.section === section);
    return acc;
  }, {} as Record<string, Table[]>);

  return {
    tables: data,
    isLoading,
    error,
    refetch,
    createTable,
    updateTable,
    deleteTable,
    stats,
    sections,
    tablesBySection,
  };
}

// =============================================
// CATEGORIES HOOK
// =============================================
export function useCategories(venueId: string | null) {
  const [data, setData] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    if (!venueId) {
      setData([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const { data: result, error: fetchError } = await supabase
        .from('categories')
        .select('*')
        .eq('venue_id', venueId)
        .eq('is_active', true)
        .order('sort_order', { ascending: true });

      if (fetchError) throw fetchError;
      setData(result || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [venueId]);

  useEffect(() => {
    fetch();
  }, [fetch]);

  const createCategory = async (category: Omit<Category, 'id' | 'created_at'>) => {
    const { data: newCat, error } = await supabase
      .from('categories')
      .insert(category)
      .select()
      .single();

    if (error) throw error;
    await fetch();
    return newCat;
  };

  const updateCategory = async (id: string, updates: Partial<Category>) => {
    const { data: updated, error } = await supabase
      .from('categories')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    await fetch();
    return updated;
  };

  const deleteCategory = async (id: string) => {
    // Soft delete
    const { error } = await supabase
      .from('categories')
      .update({ is_active: false })
      .eq('id', id);

    if (error) throw error;
    await fetch();
  };

  return {
    categories: data,
    isLoading,
    error,
    refetch: fetch,
    createCategory,
    updateCategory,
    deleteCategory,
  };
}

// =============================================
// PRODUCTS HOOK
// =============================================
export function useProducts(venueId: string | null, categoryId?: string | null) {
  const [data, setData] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    if (!venueId) {
      setData([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      let query = supabase
        .from('products')
        .select('*')
        .eq('venue_id', venueId)
        .order('sort_order', { ascending: true });

      if (categoryId) {
        query = query.eq('category_id', categoryId);
      }

      const { data: result, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      setData(result || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [venueId, categoryId]);

  useEffect(() => {
    fetch();
  }, [fetch]);

  const createProduct = async (product: Omit<Product, 'id' | 'created_at'>) => {
    const { data: newProduct, error } = await supabase
      .from('products')
      .insert(product)
      .select()
      .single();

    if (error) throw error;
    await fetch();
    return newProduct;
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    const { data: updated, error } = await supabase
      .from('products')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    await fetch();
    return updated;
  };

  const deleteProduct = async (id: string) => {
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) throw error;
    await fetch();
  };

  const toggleAvailability = async (id: string, isAvailable: boolean) => {
    return updateProduct(id, { is_available: isAvailable });
  };

  return {
    products: data,
    isLoading,
    error,
    refetch: fetch,
    createProduct,
    updateProduct,
    deleteProduct,
    toggleAvailability,
  };
}

// =============================================
// ORDERS HOOK (Real-time)
// =============================================
export function useOrders(venueId: string | null, filters?: {
  status?: string[];
  type?: string;
  date?: string;
}) {
  const [data, setData] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    if (!venueId) {
      setData([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      let query = supabase
        .from('orders')
        .select('*')
        .eq('venue_id', venueId)
        .order('created_at', { ascending: false });

      if (filters?.status && filters.status.length > 0) {
        query = query.in('status', filters.status);
      }

      if (filters?.type) {
        query = query.eq('type', filters.type);
      }

      if (filters?.date) {
        query = query.gte('created_at', `${filters.date}T00:00:00`)
          .lte('created_at', `${filters.date}T23:59:59`);
      }

      const { data: result, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      setData(result || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [venueId, filters?.status, filters?.type, filters?.date]);

  useEffect(() => {
    fetch();

    // Real-time subscription
    if (venueId) {
      const unsubscribe = subscribeToTable('orders', venueId, (payload) => {
        if (payload.eventType === 'INSERT') {
          setData((prev) => [payload.new as Order, ...prev]);
          // Play sound for new orders
          if (typeof window !== 'undefined') {
            // Notification sound logic here
          }
        } else if (payload.eventType === 'UPDATE') {
          setData((prev) =>
            prev.map((order) =>
              order.id === payload.new.id ? (payload.new as Order) : order
            )
          );
        } else if (payload.eventType === 'DELETE') {
          setData((prev) => prev.filter((order) => order.id !== payload.old.id));
        }
      });

      return unsubscribe;
    }
  }, [fetch, venueId]);

  const updateOrderStatus = async (id: string, status: string) => {
    const { data: updated, error } = await supabase
      .from('orders')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return updated;
  };

  const updateOrderItemStatus = async (
    orderId: string,
    itemId: string,
    status: string
  ) => {
    // Get current order
    const { data: order, error: fetchError } = await supabase
      .from('orders')
      .select('items')
      .eq('id', orderId)
      .single();

    if (fetchError) throw fetchError;

    // Update item status
    const items = order.items.map((item: any) =>
      item.id === itemId ? { ...item, status } : item
    );

    // Save back
    const { data: updated, error } = await supabase
      .from('orders')
      .update({ items, updated_at: new Date().toISOString() })
      .eq('id', orderId)
      .select()
      .single();

    if (error) throw error;
    return updated;
  };

  const completePayment = async (
    id: string,
    paymentMethod: string,
    amount: number
  ) => {
    const { data: updated, error } = await supabase
      .from('orders')
      .update({
        payment_status: 'paid',
        payment_method: paymentMethod,
        status: 'completed',
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return updated;
  };

  // Kategorize orders
  const pendingOrders = data.filter((o) => o.status === 'pending');
  const preparingOrders = data.filter((o) => o.status === 'preparing');
  const readyOrders = data.filter((o) => o.status === 'ready');
  const activeOrders = data.filter((o) =>
    ['pending', 'confirmed', 'preparing', 'ready'].includes(o.status)
  );

  return {
    orders: data,
    isLoading,
    error,
    refetch: fetch,
    updateOrderStatus,
    updateOrderItemStatus,
    completePayment,
    pendingOrders,
    preparingOrders,
    readyOrders,
    activeOrders,
  };
}

// =============================================
// RESERVATIONS HOOK
// =============================================
export function useReservations(venueId: string | null, date?: string) {
  const [data, setData] = useState<Reservation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    if (!venueId) {
      setData([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      let query = supabase
        .from('reservations')
        .select('*')
        .eq('venue_id', venueId)
        .order('date', { ascending: true })
        .order('time', { ascending: true });

      if (date) {
        query = query.eq('date', date);
      }

      const { data: result, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      setData(result || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [venueId, date]);

  useEffect(() => {
    fetch();
  }, [fetch]);

  const createReservation = async (
    reservation: Omit<Reservation, 'id' | 'created_at'>
  ) => {
    const { data: newRes, error } = await supabase
      .from('reservations')
      .insert(reservation)
      .select()
      .single();

    if (error) throw error;
    await fetch();
    return newRes;
  };

  const updateReservationStatus = async (id: string, status: string) => {
    const { data: updated, error } = await supabase
      .from('reservations')
      .update({ status })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    await fetch();
    return updated;
  };

  return {
    reservations: data,
    isLoading,
    error,
    refetch: fetch,
    createReservation,
    updateReservationStatus,
    todayReservations: data.filter(
      (r) => r.date === new Date().toISOString().split('T')[0]
    ),
    pendingReservations: data.filter((r) => r.status === 'pending'),
  };
}

// =============================================
// STAFF HOOK
// =============================================
export function useStaff(venueId: string | null) {
  const { data, isLoading, error, refetch } = useFetch<Staff>(
    'staff',
    venueId
  );

  const createStaff = async (staff: Omit<Staff, 'id' | 'created_at'>) => {
    const { data: newStaff, error } = await supabase
      .from('staff')
      .insert(staff)
      .select()
      .single();

    if (error) throw error;
    await refetch();
    return newStaff;
  };

  const updateStaff = async (id: string, updates: Partial<Staff>) => {
    const { data: updated, error } = await supabase
      .from('staff')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    await refetch();
    return updated;
  };

  const activeStaff = data.filter((s) => s.is_active);
  const staffByRole = data.reduce((acc, staff) => {
    if (!acc[staff.role]) acc[staff.role] = [];
    acc[staff.role].push(staff);
    return acc;
  }, {} as Record<string, Staff[]>);

  return {
    staff: data,
    isLoading,
    error,
    refetch,
    createStaff,
    updateStaff,
    activeStaff,
    staffByRole,
  };
}

// =============================================
// STOCK HOOK
// =============================================
export function useStock(venueId: string | null) {
  const { data, isLoading, error, refetch } = useFetch<StockItem>(
    'stock_items',
    venueId
  );

  const createStockItem = async (item: Omit<StockItem, 'id' | 'created_at'>) => {
    const { data: newItem, error } = await supabase
      .from('stock_items')
      .insert(item)
      .select()
      .single();

    if (error) throw error;
    await refetch();
    return newItem;
  };

  const updateStock = async (id: string, quantity: number) => {
    const { data: updated, error } = await supabase
      .from('stock_items')
      .update({ current_quantity: quantity })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    await refetch();
    return updated;
  };

  const lowStockItems = data.filter(
    (item) => item.current_quantity <= item.min_quantity
  );

  const outOfStockItems = data.filter((item) => item.current_quantity === 0);

  return {
    stockItems: data,
    isLoading,
    error,
    refetch,
    createStockItem,
    updateStock,
    lowStockItems,
    outOfStockItems,
    lowStockCount: lowStockItems.length,
  };
}

// =============================================
// VENUE HOOK
// =============================================
export function useVenue(venueId: string | null) {
  const [venue, setVenue] = useState<Venue | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    if (!venueId) {
      setVenue(null);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const { data, error: fetchError } = await supabase
        .from('venues')
        .select('*')
        .eq('id', venueId)
        .single();

      if (fetchError) throw fetchError;
      setVenue(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [venueId]);

  useEffect(() => {
    fetch();
  }, [fetch]);

  const updateVenue = async (updates: Partial<Venue>) => {
    if (!venueId) return;

    const { data: updated, error } = await supabase
      .from('venues')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', venueId)
      .select()
      .single();

    if (error) throw error;
    setVenue(updated);
    return updated;
  };

  const updateSettings = async (settings: Partial<Venue['settings']>) => {
    if (!venue) return;

    const newSettings = { ...venue.settings, ...settings };
    return updateVenue({ settings: newSettings });
  };

  return {
    venue,
    isLoading,
    error,
    refetch: fetch,
    updateVenue,
    updateSettings,
  };
}

// =============================================
// USER VENUES HOOK
// =============================================
export function useUserVenues(userId: string | null) {
  const [venues, setVenues] = useState<Venue[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    if (!userId) {
      setVenues([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const { data: userVenues, error: uvError } = await supabase
        .from('user_venues')
        .select('venue_id, role, permissions')
        .eq('user_id', userId);

      if (uvError) throw uvError;

      if (userVenues && userVenues.length > 0) {
        const venueIds = userVenues.map((uv) => uv.venue_id);
        const { data: venuesData, error: vError } = await supabase
          .from('venues')
          .select('*')
          .in('id', venueIds)
          .eq('is_active', true);

        if (vError) throw vError;
        setVenues(venuesData || []);
      } else {
        setVenues([]);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    fetch();
  }, [fetch]);

  return {
    venues,
    isLoading,
    error,
    refetch: fetch,
    hasMultipleVenues: venues.length > 1,
  };
}

// =============================================
// COUPONS HOOK
// =============================================
export function useCoupons(venueId: string | null) {
  const { data, isLoading, error, refetch } = useFetch<Coupon>(
    'coupons',
    venueId
  );

  const createCoupon = async (coupon: Omit<Coupon, 'id' | 'created_at'>) => {
    const { data: newCoupon, error } = await supabase
      .from('coupons')
      .insert(coupon)
      .select()
      .single();

    if (error) throw error;
    await refetch();
    return newCoupon;
  };

  const validateCoupon = async (code: string, orderTotal: number) => {
    const coupon = data.find(
      (c) =>
        c.code.toLowerCase() === code.toLowerCase() &&
        c.is_active &&
        new Date(c.valid_until) >= new Date() &&
        (!c.min_order_amount || orderTotal >= c.min_order_amount) &&
        (!c.max_uses || c.used_count < c.max_uses)
    );

    return coupon || null;
  };

  const activeCoupons = data.filter(
    (c) => c.is_active && new Date(c.valid_until) >= new Date()
  );

  return {
    coupons: data,
    isLoading,
    error,
    refetch,
    createCoupon,
    validateCoupon,
    activeCoupons,
  };
}

// =============================================
// SHIFTS HOOK
// =============================================
export function useShifts(venueId: string | null, date?: string) {
  const [data, setData] = useState<Shift[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    if (!venueId) {
      setData([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      let query = supabase
        .from('shifts')
        .select('*, staff(*)')
        .eq('venue_id', venueId);

      if (date) {
        query = query.eq('date', date);
      }

      const { data: result, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      setData(result || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [venueId, date]);

  useEffect(() => {
    fetch();
  }, [fetch]);

  const todayShifts = data.filter(
    (s) => s.date === new Date().toISOString().split('T')[0]
  );

  const activeShifts = todayShifts.filter((s) => s.status === 'in_progress');

  return {
    shifts: data,
    isLoading,
    error,
    refetch: fetch,
    todayShifts,
    activeShifts,
    staffOnDuty: activeShifts.length,
  };
}
