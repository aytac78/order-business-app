// =============================================
// ORDER BUSINESS - ZUSTAND STORES
// Supabase entegrasyonlu, Customer ile uyumlu
// =============================================

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  Venue,
  VenueSummary,
  VenueAlert,
  Table,
  TableStatus,
  Order,
  Staff,
  UserVenue,
  Permission,
} from '@/types/database';

// =============================================
// VENUE STORE
// =============================================
interface VenueState {
  // Current venue
  currentVenue: Venue | null;
  currentVenueId: string | null;

  // All venues user has access to
  venues: Venue[];
  userVenues: UserVenue[];

  // Multi-venue dashboard data
  venueSummaries: VenueSummary[];
  alerts: VenueAlert[];

  // Loading states
  isLoading: boolean;
  error: string | null;

  // Actions
  setCurrentVenue: (venue: Venue | null) => void;
  setCurrentVenueById: (venueId: string) => void;
  setVenues: (venues: Venue[]) => void;
  setUserVenues: (userVenues: UserVenue[]) => void;
  setVenueSummaries: (summaries: VenueSummary[]) => void;
  addAlert: (alert: VenueAlert) => void;
  setAlerts: (alerts: VenueAlert[]) => void;
  markAlertRead: (alertId: string) => void;
  clearAlerts: () => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  reset: () => void;

  // Computed
  getCurrentVenueRole: () => string | null;
  hasPermission: (permission: Permission) => boolean;
  getUnreadAlertsCount: () => number;
}

export const useVenueStore = create<VenueState>()(
  persist(
    (set, get) => ({
      // Initial state - BOŞ, Supabase'den yüklenecek
      currentVenue: null,
      currentVenueId: null,
      venues: [],
      userVenues: [],
      venueSummaries: [],
      alerts: [],
      isLoading: false,
      error: null,

      // Actions
      setCurrentVenue: (venue) =>
        set({
          currentVenue: venue,
          currentVenueId: venue?.id || null,
        }),

      setCurrentVenueById: (venueId) => {
        const venues = get().venues;
        const venue = venues.find((v) => v.id === venueId) || null;
        set({ currentVenue: venue, currentVenueId: venueId });
      },

      setVenues: (venues) => set({ venues }),

      setUserVenues: (userVenues) => set({ userVenues }),

      setVenueSummaries: (summaries) => set({ venueSummaries: summaries }),

      addAlert: (alert) =>
        set((state) => ({
          alerts: [alert, ...state.alerts].slice(0, 100), // Max 100 alert tut
        })),

      setAlerts: (alerts) => set({ alerts }),

      markAlertRead: (alertId) =>
        set((state) => ({
          alerts: state.alerts.map((alert) =>
            alert.id === alertId ? { ...alert, is_read: true } : alert
          ),
        })),

      clearAlerts: () => set({ alerts: [] }),

      setLoading: (loading) => set({ isLoading: loading }),

      setError: (error) => set({ error }),

      reset: () =>
        set({
          currentVenue: null,
          currentVenueId: null,
          venues: [],
          userVenues: [],
          venueSummaries: [],
          alerts: [],
          isLoading: false,
          error: null,
        }),

      // Computed
      getCurrentVenueRole: () => {
        const { currentVenueId, userVenues } = get();
        if (!currentVenueId) return null;
        const userVenue = userVenues.find(
          (uv) => uv.venue_id === currentVenueId
        );
        return userVenue?.role || null;
      },

      hasPermission: (permission: Permission) => {
        const { currentVenueId, userVenues } = get();
        if (!currentVenueId) return false;
        const userVenue = userVenues.find(
          (uv) => uv.venue_id === currentVenueId
        );
        if (!userVenue) return false;
        // Owner has all permissions
        if (userVenue.role === 'owner') return true;
        return userVenue.permissions.includes(permission);
      },

      getUnreadAlertsCount: () => {
        return get().alerts.filter((a) => !a.is_read).length;
      },
    }),
    {
      name: 'order-venue-storage',
      partialize: (state) => ({
        currentVenueId: state.currentVenueId,
      }),
    }
  )
);

// =============================================
// NOTIFICATION STORE
// =============================================
interface NotificationState {
  notifications: VenueAlert[];
  unreadCount: number;
  soundEnabled: boolean;

  addNotification: (notification: VenueAlert) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  clearAll: () => void;
  toggleSound: () => void;
  setNotifications: (notifications: VenueAlert[]) => void;
}

export const useNotificationStore = create<NotificationState>()(
  persist(
    (set, get) => ({
      notifications: [],
      unreadCount: 0,
      soundEnabled: true,

      addNotification: (notification) =>
        set((state) => ({
          notifications: [notification, ...state.notifications].slice(0, 50),
          unreadCount: state.unreadCount + 1,
        })),

      markAsRead: (id) =>
        set((state) => ({
          notifications: state.notifications.map((n) =>
            n.id === id ? { ...n, is_read: true } : n
          ),
          unreadCount: Math.max(0, state.unreadCount - 1),
        })),

      markAllAsRead: () =>
        set((state) => ({
          notifications: state.notifications.map((n) => ({
            ...n,
            is_read: true,
          })),
          unreadCount: 0,
        })),

      clearAll: () => set({ notifications: [], unreadCount: 0 }),

      toggleSound: () => set((state) => ({ soundEnabled: !state.soundEnabled })),

      setNotifications: (notifications) =>
        set({
          notifications,
          unreadCount: notifications.filter((n) => !n.is_read).length,
        }),
    }),
    {
      name: 'order-notification-storage',
      partialize: (state) => ({
        soundEnabled: state.soundEnabled,
      }),
    }
  )
);

// =============================================
// UI STATE STORE
// =============================================
interface UIState {
  sidebarOpen: boolean;
  sidebarCollapsed: boolean;
  venueDrawerOpen: boolean;
  modalStack: string[];

  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  toggleSidebarCollapse: () => void;
  setVenueDrawerOpen: (open: boolean) => void;
  pushModal: (modalId: string) => void;
  popModal: () => void;
  closeAllModals: () => void;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarOpen: true,
      sidebarCollapsed: false,
      venueDrawerOpen: false,
      modalStack: [],

      toggleSidebar: () =>
        set((state) => ({ sidebarOpen: !state.sidebarOpen })),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      toggleSidebarCollapse: () =>
        set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
      setVenueDrawerOpen: (open) => set({ venueDrawerOpen: open }),
      pushModal: (modalId) =>
        set((state) => ({ modalStack: [...state.modalStack, modalId] })),
      popModal: () =>
        set((state) => ({ modalStack: state.modalStack.slice(0, -1) })),
      closeAllModals: () => set({ modalStack: [] }),
    }),
    {
      name: 'order-ui-storage',
    }
  )
);

// =============================================
// TABLE STORE - Supabase ile sync
// =============================================
interface TableState {
  tables: Table[];
  isLoading: boolean;
  error: string | null;

  setTables: (tables: Table[]) => void;
  updateTable: (id: string, updates: Partial<Table>) => void;
  addTable: (table: Table) => void;
  deleteTable: (id: string) => void;
  setTableStatus: (id: string, status: TableStatus) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;

  // Computed helpers
  getTablesBySection: (section: string) => Table[];
  getTablesByStatus: (status: TableStatus) => Table[];
  getTableById: (id: string) => Table | undefined;
  getSections: () => string[];
  getStats: () => {
    total: number;
    available: number;
    occupied: number;
    reserved: number;
    cleaning: number;
  };
}

export const useTableStore = create<TableState>()((set, get) => ({
  // Initial state - BOŞ, Supabase'den yüklenecek
  tables: [],
  isLoading: false,
  error: null,

  setTables: (tables) => set({ tables, error: null }),

  updateTable: (id, updates) =>
    set((state) => ({
      tables: state.tables.map((t) =>
        t.id === id ? { ...t, ...updates } : t
      ),
    })),

  addTable: (table) =>
    set((state) => ({
      tables: [...state.tables, table],
    })),

  deleteTable: (id) =>
    set((state) => ({
      tables: state.tables.filter((t) => t.id !== id),
    })),

  setTableStatus: (id, status) =>
    set((state) => ({
      tables: state.tables.map((t) =>
        t.id === id ? { ...t, status } : t
      ),
    })),

  setLoading: (loading) => set({ isLoading: loading }),

  setError: (error) => set({ error }),

  // Computed helpers
  getTablesBySection: (section) =>
    get().tables.filter((t) => t.section === section),

  getTablesByStatus: (status) =>
    get().tables.filter((t) => t.status === status),

  getTableById: (id) => get().tables.find((t) => t.id === id),

  getSections: () => [
    ...new Set(get().tables.map((t) => t.section).filter(Boolean) as string[]),
  ],

  getStats: () => {
    const tables = get().tables;
    return {
      total: tables.length,
      available: tables.filter((t) => t.status === 'available').length,
      occupied: tables.filter((t) => t.status === 'occupied').length,
      reserved: tables.filter((t) => t.status === 'reserved').length,
      cleaning: tables.filter((t) => t.status === 'cleaning').length,
    };
  },
}));

// =============================================
// ORDER STORE - Supabase ile sync
// =============================================
interface OrderState {
  orders: Order[];
  isLoading: boolean;
  error: string | null;

  setOrders: (orders: Order[]) => void;
  addOrder: (order: Order) => void;
  updateOrder: (id: string, updates: Partial<Order>) => void;
  removeOrder: (id: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;

  // Computed helpers
  getOrdersByStatus: (status: string) => Order[];
  getOrdersByTable: (tableId: string) => Order[];
  getActiveOrders: () => Order[];
  getPendingOrders: () => Order[];
  getPreparingOrders: () => Order[];
  getReadyOrders: () => Order[];
}

export const useOrderStore = create<OrderState>()((set, get) => ({
  // Initial state - BOŞ
  orders: [],
  isLoading: false,
  error: null,

  setOrders: (orders) => set({ orders, error: null }),

  addOrder: (order) =>
    set((state) => ({
      orders: [order, ...state.orders],
    })),

  updateOrder: (id, updates) =>
    set((state) => ({
      orders: state.orders.map((o) =>
        o.id === id ? { ...o, ...updates } : o
      ),
    })),

  removeOrder: (id) =>
    set((state) => ({
      orders: state.orders.filter((o) => o.id !== id),
    })),

  setLoading: (loading) => set({ isLoading: loading }),

  setError: (error) => set({ error }),

  // Computed helpers
  getOrdersByStatus: (status) =>
    get().orders.filter((o) => o.status === status),

  getOrdersByTable: (tableId) =>
    get().orders.filter((o) => o.table_id === tableId),

  getActiveOrders: () =>
    get().orders.filter((o) =>
      ['pending', 'confirmed', 'preparing', 'ready'].includes(o.status)
    ),

  getPendingOrders: () => get().orders.filter((o) => o.status === 'pending'),

  getPreparingOrders: () =>
    get().orders.filter((o) => o.status === 'preparing'),

  getReadyOrders: () => get().orders.filter((o) => o.status === 'ready'),
}));

// =============================================
// STAFF STORE
// =============================================
interface StaffState {
  staff: Staff[];
  currentStaff: Staff | null;
  isLoading: boolean;
  error: string | null;

  setStaff: (staff: Staff[]) => void;
  setCurrentStaff: (staff: Staff | null) => void;
  addStaff: (staff: Staff) => void;
  updateStaff: (id: string, updates: Partial<Staff>) => void;
  removeStaff: (id: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

export const useStaffStore = create<StaffState>()((set) => ({
  staff: [],
  currentStaff: null,
  isLoading: false,
  error: null,

  setStaff: (staff) => set({ staff, error: null }),

  setCurrentStaff: (staff) => set({ currentStaff: staff }),

  addStaff: (staff) =>
    set((state) => ({
      staff: [...state.staff, staff],
    })),

  updateStaff: (id, updates) =>
    set((state) => ({
      staff: state.staff.map((s) =>
        s.id === id ? { ...s, ...updates } : s
      ),
    })),

  removeStaff: (id) =>
    set((state) => ({
      staff: state.staff.filter((s) => s.id !== id),
    })),

  setLoading: (loading) => set({ isLoading: loading }),

  setError: (error) => set({ error }),
}));

// =============================================
// CART STORE (POS için)
// =============================================
interface CartItem {
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  notes?: string;
  options?: { option_name: string; choice_name: string; price_modifier: number }[];
}

interface CartState {
  items: CartItem[];
  tableId: string | null;
  tableNumber: string | null;
  orderType: 'dine_in' | 'takeaway' | 'delivery';
  notes: string;
  discount: number;
  discountType: 'percent' | 'amount';

  addItem: (item: CartItem) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  setTable: (tableId: string | null, tableNumber: string | null) => void;
  setOrderType: (type: 'dine_in' | 'takeaway' | 'delivery') => void;
  setNotes: (notes: string) => void;
  setDiscount: (amount: number, type: 'percent' | 'amount') => void;
  clearCart: () => void;

  // Computed
  getSubtotal: () => number;
  getDiscountAmount: () => number;
  getTax: () => number;
  getTotal: () => number;
  getItemCount: () => number;
}

export const useCartStore = create<CartState>()((set, get) => ({
  items: [],
  tableId: null,
  tableNumber: null,
  orderType: 'dine_in',
  notes: '',
  discount: 0,
  discountType: 'percent',

  addItem: (item) =>
    set((state) => {
      const existing = state.items.find(
        (i) => i.product_id === item.product_id
      );
      if (existing) {
        return {
          items: state.items.map((i) =>
            i.product_id === item.product_id
              ? {
                  ...i,
                  quantity: i.quantity + item.quantity,
                  total_price: (i.quantity + item.quantity) * i.unit_price,
                }
              : i
          ),
        };
      }
      return { items: [...state.items, item] };
    }),

  removeItem: (productId) =>
    set((state) => ({
      items: state.items.filter((i) => i.product_id !== productId),
    })),

  updateQuantity: (productId, quantity) =>
    set((state) => ({
      items:
        quantity <= 0
          ? state.items.filter((i) => i.product_id !== productId)
          : state.items.map((i) =>
              i.product_id === productId
                ? { ...i, quantity, total_price: quantity * i.unit_price }
                : i
            ),
    })),

  setTable: (tableId, tableNumber) => set({ tableId, tableNumber }),

  setOrderType: (type) => set({ orderType: type }),

  setNotes: (notes) => set({ notes }),

  setDiscount: (amount, type) => set({ discount: amount, discountType: type }),

  clearCart: () =>
    set({
      items: [],
      tableId: null,
      tableNumber: null,
      orderType: 'dine_in',
      notes: '',
      discount: 0,
      discountType: 'percent',
    }),

  // Computed
  getSubtotal: () => get().items.reduce((sum, i) => sum + i.total_price, 0),

  getDiscountAmount: () => {
    const { discount, discountType } = get();
    const subtotal = get().getSubtotal();
    return discountType === 'percent'
      ? (subtotal * discount) / 100
      : discount;
  },

  getTax: () => {
    const subtotal = get().getSubtotal();
    const discountAmount = get().getDiscountAmount();
    return (subtotal - discountAmount) * 0.08; // %8 KDV
  },

  getTotal: () => {
    const subtotal = get().getSubtotal();
    const discountAmount = get().getDiscountAmount();
    const tax = get().getTax();
    return subtotal - discountAmount + tax;
  },

  getItemCount: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
}));

// =============================================
// EXPORT ALL
// =============================================
export type {
  VenueState,
  NotificationState,
  UIState,
  TableState,
  OrderState,
  StaffState,
  CartState,
  CartItem,
};
