// =============================================
// ORDER BUSINESS - TÜRKÇE ÇEVİRİLER
// =============================================

export const tr = {
  // =============================================
  // GENEL
  // =============================================
  common: {
    save: 'Kaydet',
    cancel: 'İptal',
    delete: 'Sil',
    edit: 'Düzenle',
    add: 'Ekle',
    search: 'Ara',
    filter: 'Filtrele',
    refresh: 'Yenile',
    loading: 'Yükleniyor...',
    noData: 'Veri bulunamadı',
    confirm: 'Onayla',
    back: 'Geri',
    next: 'İleri',
    close: 'Kapat',
    yes: 'Evet',
    no: 'Hayır',
    all: 'Tümü',
    active: 'Aktif',
    inactive: 'Pasif',
    status: 'Durum',
    actions: 'İşlemler',
    details: 'Detaylar',
    total: 'Toplam',
    subtotal: 'Ara Toplam',
    tax: 'KDV',
    discount: 'İndirim',
    date: 'Tarih',
    time: 'Saat',
    name: 'Ad',
    phone: 'Telefon',
    email: 'E-posta',
    address: 'Adres',
    notes: 'Notlar',
    description: 'Açıklama',
    price: 'Fiyat',
    quantity: 'Adet',
    currency: 'Para Birimi',
  },

  // =============================================
  // AYARLAR
  // =============================================
  settings: {
    title: 'Ayarlar',
    venueName: 'Mekan Adı',
    phone: 'Telefon',
    email: 'E-posta',
    address: 'Adres',
    city: 'Şehir',
    district: 'İlçe',
    timezone: 'Saat Dilimi',
    currency: 'Para Birimi',
    taxRate: 'KDV Oranı (%)',
    serviceCharge: 'Servis Ücreti (%)',
    minOrderAmount: 'Minimum Sipariş Tutarı',
    
    // Tabs
    general: 'Genel',
    workingHours: 'Çalışma Saatleri',
    orderSettings: 'Sipariş Ayarları',
    paymentSettings: 'Ödeme Ayarları',
    notifications: 'Bildirimler',
    
    // Working Hours
    monday: 'Pazartesi',
    tuesday: 'Salı',
    wednesday: 'Çarşamba',
    thursday: 'Perşembe',
    friday: 'Cuma',
    saturday: 'Cumartesi',
    sunday: 'Pazar',
    open: 'Açılış',
    close: 'Kapanış',
    closed: 'Kapalı',
    
    // Order Settings
    autoAcceptOrders: 'Siparişleri Otomatik Kabul Et',
    qrMenuEnabled: 'QR Menü Aktif',
    onlineOrderingEnabled: 'Online Sipariş Aktif',
    reservationEnabled: 'Rezervasyon Aktif',
    
    // Payment Settings
    cashEnabled: 'Nakit',
    cardEnabled: 'Kredi Kartı',
    titPayEnabled: 'TiT Pay',
    multinetEnabled: 'Multinet',
    sodexoEnabled: 'Sodexo',
    ticketEnabled: 'Ticket',
    
    // Notifications
    soundEnabled: 'Bildirim Sesleri',
    newOrderSound: 'Yeni Sipariş Sesi',
    reservationSound: 'Rezervasyon Sesi',
  },

  // =============================================
  // MENÜ
  // =============================================
  menu: {
    title: 'Menü Yönetimi',
    categories: 'Kategoriler',
    products: 'Ürünler',
    addCategory: 'Kategori Ekle',
    addProduct: 'Ürün Ekle',
    editCategory: 'Kategori Düzenle',
    editProduct: 'Ürün Düzenle',
    
    // Category
    categoryName: 'Kategori Adı',
    categoryDescription: 'Kategori Açıklaması',
    categoryImage: 'Kategori Görseli',
    sortOrder: 'Sıralama',
    
    // Product
    productName: 'Ürün Adı',
    productDescription: 'Ürün Açıklaması',
    productPrice: 'Ürün Fiyatı (₺)',
    productImage: 'Ürün Görseli',
    preparationTime: 'Hazırlama Süresi (dk)',
    isAvailable: 'Satışta',
    allergens: 'Alerjenler',
    options: 'Seçenekler',
    
    // Filters
    allCategories: 'Tüm Kategoriler',
    availableOnly: 'Sadece Satışta',
    
    // Messages
    noCategories: 'Henüz kategori eklenmemiş',
    noProducts: 'Bu kategoride ürün yok',
    productAdded: 'Ürün başarıyla eklendi',
    productUpdated: 'Ürün başarıyla güncellendi',
    productDeleted: 'Ürün silindi',
    categoryAdded: 'Kategori başarıyla eklendi',
    categoryDeleted: 'Kategori silindi',
    selectCategory: 'Kategori seçin',
  },

  // =============================================
  // MASALAR
  // =============================================
  tables: {
    title: 'Masalar',
    addTable: 'Masa Ekle',
    editTable: 'Masa Düzenle',
    tableNumber: 'Masa No',
    tableName: 'Masa Adı',
    capacity: 'Kapasite',
    section: 'Bölüm',
    shape: 'Şekil',
    
    // Status
    available: 'Müsait',
    occupied: 'Dolu',
    reserved: 'Rezerveli',
    cleaning: 'Temizleniyor',
    
    // Shapes
    square: 'Kare',
    round: 'Yuvarlak',
    rectangle: 'Dikdörtgen',
    
    // Sections
    indoor: 'İç Mekan',
    outdoor: 'Dış Mekan',
    terrace: 'Teras',
    garden: 'Bahçe',
    vip: 'VIP',
    
    // Actions
    openOrder: 'Sipariş Aç',
    viewOrder: 'Sipariş Görüntüle',
    closeTable: 'Masayı Kapat',
    transferTable: 'Masa Aktar',
    mergeTable: 'Masa Birleştir',
    
    // Stats
    totalTables: 'Toplam Masa',
    occupiedTables: 'Dolu',
    availableTables: 'Müsait',
    reservedTables: 'Rezerveli',
    cleaningTables: 'Temizleniyor',
    
    // Messages
    noTables: 'Henüz masa eklenmemiş',
    tableAdded: 'Masa başarıyla eklendi',
    tableUpdated: 'Masa güncellendi',
    tableDeleted: 'Masa silindi',
    allSections: 'Tüm Bölümler',
  },

  // =============================================
  // SİPARİŞLER
  // =============================================
  orders: {
    title: 'Siparişler',
    newOrder: 'Yeni Sipariş',
    orderNumber: 'Sipariş No',
    orderType: 'Sipariş Tipi',
    orderStatus: 'Sipariş Durumu',
    orderItems: 'Sipariş Kalemleri',
    orderNotes: 'Sipariş Notu',
    
    // Types
    dineIn: 'Masada',
    takeaway: 'Paket',
    delivery: 'Teslimat',
    qrOrder: 'QR Sipariş',
    
    // Status
    pending: 'Bekliyor',
    confirmed: 'Onaylandı',
    preparing: 'Hazırlanıyor',
    ready: 'Hazır',
    served: 'Servis Edildi',
    completed: 'Tamamlandı',
    cancelled: 'İptal',
    
    // Payment
    paymentStatus: 'Ödeme Durumu',
    paymentMethod: 'Ödeme Yöntemi',
    paid: 'Ödendi',
    unpaid: 'Ödenmedi',
    partial: 'Kısmi Ödeme',
    
    // Actions
    acceptOrder: 'Siparişi Kabul Et',
    rejectOrder: 'Siparişi Reddet',
    startPreparing: 'Hazırlamaya Başla',
    markReady: 'Hazır İşaretle',
    markServed: 'Servis Edildi',
    completeOrder: 'Siparişi Tamamla',
    cancelOrder: 'Siparişi İptal Et',
    printOrder: 'Siparişi Yazdır',
    
    // Messages
    noOrders: 'Aktif sipariş yok',
    orderAccepted: 'Sipariş kabul edildi',
    orderRejected: 'Sipariş reddedildi',
    orderCompleted: 'Sipariş tamamlandı',
  },

  // =============================================
  // MUTFAK
  // =============================================
  kitchen: {
    title: 'Mutfak Ekranı',
    pendingOrders: 'Bekleyen',
    preparingOrders: 'Hazırlanıyor',
    readyOrders: 'Hazır',
    
    startOrder: 'Hazırlamaya Başla',
    completeItem: 'Tamamla',
    completeAll: 'Tümü Hazır',
    serveOrder: 'Servis Edildi',
    
    priority: {
      normal: 'Normal',
      rush: 'Acil',
    },
    
    // Messages
    noPending: 'Bekleyen sipariş yok',
    noPreparing: 'Hazırlanan sipariş yok',
    noReady: 'Hazır sipariş yok',
    clickToComplete: 'Tıkla: Hazır',
  },

  // =============================================
  // KASA / POS
  // =============================================
  pos: {
    title: 'Kasa',
    openChecks: 'Açık Hesaplar',
    totalToday: 'Bugün Toplam',
    transactions: 'işlem',
    open: 'açık',
    
    // Payment
    takePayment: 'Ödeme Al',
    paymentMethod: 'Ödeme Yöntemi',
    amountReceived: 'Alınan Tutar',
    change: 'Para Üstü',
    
    // Methods
    cash: 'Nakit',
    card: 'Kredi Kartı',
    titPay: 'TiT Pay',
    multinet: 'Multinet',
    sodexo: 'Sodexo',
    ticket: 'Ticket',
    mobilePayment: 'Mobil Ödeme',
    
    // Actions
    applyDiscount: 'İndirim Uygula',
    splitBill: 'Hesabı Böl',
    printReceipt: 'Fiş Yazdır',
    printPreBill: 'Ön Hesap Yazdır',
    
    // Split
    splitByPerson: 'Kişi Başı',
    numberOfPeople: 'Kişi Sayısı',
    perPerson: 'Kişi Başı',
    
    // Discount
    discountPercent: 'Yüzde (%)',
    discountAmount: 'Tutar (₺)',
    removeDiscount: 'İndirimi Kaldır',
    
    // Payment modes
    fullPayment: 'Tam Ödeme',
    partialPayment: 'Kısmi Ödeme',
    splitPayment: 'Bölümlü Ödeme',
    
    // Messages
    selectCheck: 'Hesap seçin',
    paymentReceived: 'Ödeme alındı!',
    paymentComplete: 'Ödemeyi Tamamla',
    quickPayment: 'Hızlı Ödeme',
    allVenues: 'Tüm Mekanlar',
    todayTotal: 'Bugün Toplam',
  },

  // =============================================
  // REZERVASYON
  // =============================================
  reservations: {
    title: 'Rezervasyonlar',
    newReservation: 'Yeni Rezervasyon',
    customerName: 'Müşteri Adı',
    customerPhone: 'Telefon',
    partySize: 'Kişi Sayısı',
    date: 'Tarih',
    time: 'Saat',
    table: 'Masa',
    specialRequests: 'Özel İstekler',
    deposit: 'Depozito',
    
    // Status
    pending: 'Bekliyor',
    confirmed: 'Onaylandı',
    seated: 'Oturdu',
    completed: 'Tamamlandı',
    cancelled: 'İptal',
    noShow: 'Gelmedi',
    
    // Actions
    confirmReservation: 'Rezervasyonu Onayla',
    seatGuests: 'Misafirleri Oturt',
    cancelReservation: 'Rezervasyonu İptal Et',
    
    // Messages
    noReservations: 'Rezervasyon yok',
    reservationConfirmed: 'Rezervasyon onaylandı',
    reservationCancelled: 'Rezervasyon iptal edildi',
  },

  // =============================================
  // PERSONEL
  // =============================================
  staff: {
    title: 'Personel',
    addStaff: 'Personel Ekle',
    editStaff: 'Personel Düzenle',
    name: 'Ad Soyad',
    role: 'Rol',
    phone: 'Telefon',
    email: 'E-posta',
    pinCode: 'PIN Kodu',
    hourlyRate: 'Saat Ücreti',
    
    // Roles
    owner: 'Sahip',
    manager: 'Müdür',
    cashier: 'Kasiyer',
    waiter: 'Garson',
    kitchenStaff: 'Mutfak',
    reception: 'Resepsiyon',
    
    // Messages
    noStaff: 'Personel eklenmemiş',
    staffAdded: 'Personel eklendi',
    staffUpdated: 'Personel güncellendi',
    staffDeleted: 'Personel silindi',
  },

  // =============================================
  // VARDİYA
  // =============================================
  shifts: {
    title: 'Vardiyalar',
    addShift: 'Vardiya Ekle',
    staffMember: 'Personel',
    date: 'Tarih',
    startTime: 'Başlangıç',
    endTime: 'Bitiş',
    breakMinutes: 'Mola (dk)',
    
    // Status
    scheduled: 'Planlandı',
    inProgress: 'Devam Ediyor',
    completed: 'Tamamlandı',
    missed: 'Gelmedi',
    
    // Messages
    noShifts: 'Vardiya eklenmemiş',
  },

  // =============================================
  // STOK
  // =============================================
  stock: {
    title: 'Stok Yönetimi',
    addItem: 'Stok Kalemi Ekle',
    itemName: 'Ürün Adı',
    unit: 'Birim',
    currentQuantity: 'Mevcut Miktar',
    minQuantity: 'Minimum Miktar',
    maxQuantity: 'Maksimum Miktar',
    costPerUnit: 'Birim Maliyet',
    category: 'Kategori',
    supplier: 'Tedarikçi',
    lastRestocked: 'Son Stok Girişi',
    
    // Units
    kg: 'Kilogram',
    lt: 'Litre',
    pcs: 'Adet',
    box: 'Kutu',
    
    // Alerts
    lowStock: 'Düşük Stok',
    outOfStock: 'Stok Tükendi',
    expiringSoon: 'Yakında Sona Eriyor',
    
    // Messages
    noItems: 'Stok kalemi eklenmemiş',
    itemAdded: 'Stok eklendi',
    itemUpdated: 'Stok güncellendi',
  },

  // =============================================
  // RAPORLAR
  // =============================================
  reports: {
    title: 'Raporlar',
    dailySummary: 'Günlük Özet',
    weeklySummary: 'Haftalık Özet',
    monthlySummary: 'Aylık Özet',
    
    totalRevenue: 'Toplam Gelir',
    totalOrders: 'Toplam Sipariş',
    averageOrderValue: 'Ortalama Sipariş',
    topProducts: 'En Çok Satanlar',
    ordersByType: 'Sipariş Tiplerine Göre',
    paymentBreakdown: 'Ödeme Dağılımı',
    
    // Export
    exportPDF: 'PDF İndir',
    exportExcel: 'Excel İndir',
  },

  // =============================================
  // CRM
  // =============================================
  crm: {
    title: 'Müşteri CRM',
    totalCustomers: 'Toplam Müşteri',
    vipCustomers: 'VIP Müşteriler',
    newCustomers: 'Yeni Müşteriler',
    
    customerName: 'Müşteri Adı',
    totalVisits: 'Toplam Ziyaret',
    totalSpent: 'Toplam Harcama',
    lastVisit: 'Son Ziyaret',
    tags: 'Etiketler',
    
    // Messages
    noCustomers: 'Müşteri kaydı yok',
  },

  // =============================================
  // KUPONLAR
  // =============================================
  coupons: {
    title: 'Kuponlar',
    addCoupon: 'Kupon Ekle',
    couponCode: 'Kupon Kodu',
    couponName: 'Kupon Adı',
    discountType: 'İndirim Tipi',
    discountValue: 'İndirim Değeri',
    minOrderAmount: 'Minimum Sipariş',
    maxUses: 'Maksimum Kullanım',
    usedCount: 'Kullanım Sayısı',
    validFrom: 'Geçerlilik Başlangıcı',
    validUntil: 'Geçerlilik Bitişi',
    
    // Types
    percentage: 'Yüzde',
    fixed: 'Sabit Tutar',
    freeItem: 'Ücretsiz Ürün',
    
    // Messages
    noCoupons: 'Kupon eklenmemiş',
    couponAdded: 'Kupon eklendi',
    couponExpired: 'Kupon süresi dolmuş',
  },

  // =============================================
  // GARSON PANELİ
  // =============================================
  waiter: {
    title: 'Garson Paneli',
    myTables: 'Masalarım',
    activeOrders: 'Aktif Siparişler',
    callWaiter: 'Garson Çağrısı',
    
    // Actions
    takeOrder: 'Sipariş Al',
    addItems: 'Ürün Ekle',
    requestBill: 'Hesap İste',
    
    // Messages
    noActiveTables: 'Aktif masanız yok',
    waiterCalled: 'Garson çağrıldı',
  },

  // =============================================
  // DASHBOARD
  // =============================================
  dashboard: {
    title: 'Dashboard',
    todayRevenue: 'Bugünkü Gelir',
    todayOrders: 'Bugünkü Sipariş',
    activeOrders: 'Aktif Sipariş',
    pendingReservations: 'Bekleyen Rezervasyon',
    lowStockItems: 'Düşük Stok',
    staffOnDuty: 'Görevdeki Personel',
    occupancyRate: 'Doluluk Oranı',
    
    // Widgets
    recentOrders: 'Son Siparişler',
    upcomingReservations: 'Yaklaşan Rezervasyonlar',
    stockAlerts: 'Stok Uyarıları',
    performanceChart: 'Performans Grafiği',
  },

  // =============================================
  // SIDEBAR
  // =============================================
  sidebar: {
    mainMenu: 'Ana Menü',
    dashboard: 'Dashboard',
    myVenues: 'Mekanlarım',
    quickSetup: 'Hızlı Kayıt',
    
    operations: 'Operasyon',
    tables: 'Masalar',
    orders: 'Siparişler',
    waiterPanel: 'Garson Paneli',
    kitchen: 'Mutfak',
    reception: 'Resepsiyon',
    
    management: 'Yönetim',
    menu: 'Menü',
    reservations: 'Rezervasyonlar',
    pos: 'Kasa/POS',
    qrMenu: 'QR Menü',
    coupons: 'Kuponlar',
    
    stockStaff: 'Stok & Personel',
    stockManagement: 'Stok Yönetimi',
    stockAlerts: 'Stok Uyarıları',
    staff: 'Personel',
    shifts: 'Vardiyalar',
    performance: 'Performans',
    
    analytics: 'Analiz & CRM',
    reports: 'Raporlar',
    analyticsPage: 'Analitik',
    customerCRM: 'Müşteri CRM',
    
    system: 'Sistem',
    settings: 'Ayarlar',
  },

  // =============================================
  // ERRORS & MESSAGES
  // =============================================
  errors: {
    generic: 'Bir hata oluştu',
    networkError: 'Bağlantı hatası',
    notFound: 'Bulunamadı',
    unauthorized: 'Yetkisiz erişim',
    validationError: 'Lütfen tüm alanları doldurun',
    saveError: 'Kaydetme hatası',
    deleteError: 'Silme hatası',
    loadError: 'Yükleme hatası',
  },

  messages: {
    saved: 'Kaydedildi',
    deleted: 'Silindi',
    updated: 'Güncellendi',
    created: 'Oluşturuldu',
    confirmDelete: 'Silmek istediğinize emin misiniz?',
    noDataFound: 'Veri bulunamadı',
    selectVenue: 'Lütfen bir mekan seçin',
  },
};

// =============================================
// HELPER: Get translation by key path
// =============================================
export function t(key: string): string {
  const keys = key.split('.');
  let value: any = tr;
  
  for (const k of keys) {
    if (value && typeof value === 'object' && k in value) {
      value = value[k];
    } else {
      // Key bulunamadı, key'i döndür
      console.warn(`Translation not found: ${key}`);
      return key;
    }
  }
  
  return typeof value === 'string' ? value : key;
}

// Export default
export default tr;
