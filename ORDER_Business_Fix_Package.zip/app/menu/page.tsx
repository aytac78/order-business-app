'use client';

import { useState, useEffect } from 'react';
import { useVenueStore } from '@/stores';
import { useCategories, useProducts } from '@/hooks/useSupabase';
import { t } from '@/translations/tr';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  MoreVertical,
  Image as ImageIcon,
  Clock,
  Check,
  X,
  RefreshCw,
  ChevronRight,
  AlertCircle,
} from 'lucide-react';
import type { Category, Product } from '@/types/database';

export default function MenuPage() {
  const { currentVenue, currentVenueId } = useVenueStore();
  const {
    categories,
    isLoading: categoriesLoading,
    createCategory,
    updateCategory,
    deleteCategory,
    refetch: refetchCategories,
  } = useCategories(currentVenueId);

  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const {
    products,
    isLoading: productsLoading,
    createProduct,
    updateProduct,
    deleteProduct,
    toggleAvailability,
    refetch: refetchProducts,
  } = useProducts(currentVenueId, selectedCategoryId);

  const [searchQuery, setSearchQuery] = useState('');
  const [showAddCategory, setShowAddCategory] = useState(false);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form states
  const [categoryForm, setCategoryForm] = useState({
    name: '',
    description: '',
    image_url: '',
  });

  const [productForm, setProductForm] = useState({
    name: '',
    description: '',
    price: '',
    category_id: '',
    preparation_time: '',
    image_url: '',
    is_available: true,
  });

  // Reset form when modal closes
  useEffect(() => {
    if (!showAddCategory && !editingCategory) {
      setCategoryForm({ name: '', description: '', image_url: '' });
    }
  }, [showAddCategory, editingCategory]);

  useEffect(() => {
    if (!showAddProduct && !editingProduct) {
      setProductForm({
        name: '',
        description: '',
        price: '',
        category_id: selectedCategoryId || '',
        preparation_time: '',
        image_url: '',
        is_available: true,
      });
    }
  }, [showAddProduct, editingProduct, selectedCategoryId]);

  // Set category form when editing
  useEffect(() => {
    if (editingCategory) {
      setCategoryForm({
        name: editingCategory.name,
        description: editingCategory.description || '',
        image_url: editingCategory.image_url || '',
      });
    }
  }, [editingCategory]);

  // Set product form when editing
  useEffect(() => {
    if (editingProduct) {
      setProductForm({
        name: editingProduct.name,
        description: editingProduct.description || '',
        price: editingProduct.price.toString(),
        category_id: editingProduct.category_id,
        preparation_time: editingProduct.preparation_time?.toString() || '',
        image_url: editingProduct.image_url || '',
        is_available: editingProduct.is_available,
      });
    }
  }, [editingProduct]);

  // Handlers
  const handleSaveCategory = async () => {
    if (!currentVenueId || !categoryForm.name.trim()) return;

    try {
      if (editingCategory) {
        await updateCategory(editingCategory.id, {
          name: categoryForm.name,
          description: categoryForm.description || undefined,
          image_url: categoryForm.image_url || undefined,
        });
      } else {
        await createCategory({
          venue_id: currentVenueId,
          name: categoryForm.name,
          description: categoryForm.description || undefined,
          image_url: categoryForm.image_url || undefined,
          sort_order: categories.length,
          is_active: true,
        });
      }
      setShowAddCategory(false);
      setEditingCategory(null);
    } catch (err) {
      console.error('Kategori kaydetme hatası:', err);
    }
  };

  const handleSaveProduct = async () => {
    if (!currentVenueId || !productForm.name.trim() || !productForm.price || !productForm.category_id) return;

    try {
      const productData = {
        venue_id: currentVenueId,
        category_id: productForm.category_id,
        name: productForm.name,
        description: productForm.description || undefined,
        price: parseFloat(productForm.price),
        preparation_time: productForm.preparation_time ? parseInt(productForm.preparation_time) : undefined,
        image_url: productForm.image_url || undefined,
        is_available: productForm.is_available,
        sort_order: products.length,
      };

      if (editingProduct) {
        await updateProduct(editingProduct.id, productData);
      } else {
        await createProduct(productData);
      }
      setShowAddProduct(false);
      setEditingProduct(null);
    } catch (err) {
      console.error('Ürün kaydetme hatası:', err);
    }
  };

  const handleDeleteCategory = async (id: string) => {
    if (!confirm(t('messages.confirmDelete'))) return;
    try {
      await deleteCategory(id);
      if (selectedCategoryId === id) {
        setSelectedCategoryId(null);
      }
    } catch (err) {
      console.error('Kategori silme hatası:', err);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm(t('messages.confirmDelete'))) return;
    try {
      await deleteProduct(id);
    } catch (err) {
      console.error('Ürün silme hatası:', err);
    }
  };

  // Filter products by search
  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // No venue selected
  if (!currentVenue) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">{t('messages.selectVenue')}</h2>
          <p className="text-gray-400">Menü yönetimi için bir mekan seçin.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">{t('menu.title')}</h1>
          <p className="text-gray-400">
            {categories.length} {t('menu.categories')} • {products.length} {t('menu.products')}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              refetchCategories();
              refetchProducts();
            }}
            className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <RefreshCw className="w-5 h-5 text-gray-400" />
          </button>
          <button
            onClick={() => setShowAddCategory(true)}
            className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg flex items-center gap-2 transition-colors"
          >
            <Plus className="w-5 h-5" />
            {t('menu.addCategory')}
          </button>
          <button
            onClick={() => setShowAddProduct(true)}
            className="px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white rounded-lg flex items-center gap-2 transition-colors"
          >
            <Plus className="w-5 h-5" />
            {t('menu.addProduct')}
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={`${t('common.search')}...`}
          className="w-full pl-12 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-orange-500"
        />
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Categories Sidebar */}
        <div className="col-span-3 space-y-2">
          <button
            onClick={() => setSelectedCategoryId(null)}
            className={`w-full p-4 rounded-xl text-left transition-colors ${
              selectedCategoryId === null
                ? 'bg-orange-500 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            <span className="font-medium">{t('menu.allCategories')}</span>
            <span className="ml-2 text-sm opacity-70">({products.length})</span>
          </button>

          {categoriesLoading ? (
            <div className="p-4 text-center text-gray-500">{t('common.loading')}</div>
          ) : categories.length === 0 ? (
            <div className="p-4 text-center text-gray-500">{t('menu.noCategories')}</div>
          ) : (
            categories.map((category) => (
              <div
                key={category.id}
                className={`group relative p-4 rounded-xl transition-colors cursor-pointer ${
                  selectedCategoryId === category.id
                    ? 'bg-orange-500 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
                onClick={() => setSelectedCategoryId(category.id)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-medium">{category.name}</span>
                    {category.description && (
                      <p className="text-xs mt-1 opacity-70 truncate">{category.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingCategory(category);
                      }}
                      className="p-1.5 hover:bg-white/10 rounded-lg"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteCategory(category.id);
                      }}
                      className="p-1.5 hover:bg-red-500/20 rounded-lg text-red-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Products Grid */}
        <div className="col-span-9">
          {productsLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-gray-500">{t('common.loading')}</div>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-gray-500">
              <ImageIcon className="w-16 h-16 mb-4 opacity-50" />
              <p>{t('menu.noProducts')}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className={`bg-gray-800 rounded-xl overflow-hidden border transition-all ${
                    product.is_available
                      ? 'border-gray-700 hover:border-gray-600'
                      : 'border-red-900/50 opacity-60'
                  }`}
                >
                  {/* Product Image */}
                  <div className="h-32 bg-gray-700 relative">
                    {product.image_url ? (
                      <img
                        src={product.image_url}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ImageIcon className="w-12 h-12 text-gray-600" />
                      </div>
                    )}
                    {!product.is_available && (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <span className="px-3 py-1 bg-red-500 text-white text-sm rounded-full">
                          Satışta Değil
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Product Info */}
                  <div className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-white">{product.name}</h3>
                      <button
                        onClick={() => toggleAvailability(product.id, !product.is_available)}
                        className={`p-1.5 rounded-lg transition-colors ${
                          product.is_available
                            ? 'bg-green-500/20 text-green-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}
                      >
                        {product.is_available ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <X className="w-4 h-4" />
                        )}
                      </button>
                    </div>

                    {product.description && (
                      <p className="text-sm text-gray-400 mb-3 line-clamp-2">
                        {product.description}
                      </p>
                    )}

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-lg font-bold text-orange-500">
                          ₺{product.price.toLocaleString()}
                        </span>
                        {product.preparation_time && (
                          <span className="ml-2 text-xs text-gray-500 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {product.preparation_time} dk
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setEditingProduct(product)}
                          className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4 text-gray-400" />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(product.id)}
                          className="p-2 hover:bg-red-500/20 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Category Modal */}
      {(showAddCategory || editingCategory) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-2xl w-full max-w-md p-6">
            <h2 className="text-xl font-bold text-white mb-4">
              {editingCategory ? t('menu.editCategory') : t('menu.addCategory')}
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  {t('menu.categoryName')}
                </label>
                <input
                  type="text"
                  value={categoryForm.name}
                  onChange={(e) =>
                    setCategoryForm({ ...categoryForm, name: e.target.value })
                  }
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  placeholder="Örn: Ana Yemekler"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  {t('menu.categoryDescription')}
                </label>
                <textarea
                  value={categoryForm.description}
                  onChange={(e) =>
                    setCategoryForm({ ...categoryForm, description: e.target.value })
                  }
                  rows={3}
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                  placeholder="Kategori açıklaması (opsiyonel)"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  {t('menu.categoryImage')}
                </label>
                <input
                  type="url"
                  value={categoryForm.image_url}
                  onChange={(e) =>
                    setCategoryForm({ ...categoryForm, image_url: e.target.value })
                  }
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  placeholder="https://..."
                />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  setShowAddCategory(false);
                  setEditingCategory(null);
                }}
                className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-xl transition-colors"
              >
                {t('common.cancel')}
              </button>
              <button
                onClick={handleSaveCategory}
                disabled={!categoryForm.name.trim()}
                className="flex-1 py-3 bg-orange-500 hover:bg-orange-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-xl transition-colors"
              >
                {t('common.save')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Product Modal */}
      {(showAddProduct || editingProduct) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-xl font-bold text-white mb-4">
                {editingProduct ? t('menu.editProduct') : t('menu.addProduct')}
              </h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {t('menu.productName')}
                  </label>
                  <input
                    type="text"
                    value={productForm.name}
                    onChange={(e) =>
                      setProductForm({ ...productForm, name: e.target.value })
                    }
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="Örn: Izgara Levrek"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {t('menu.productDescription')}
                  </label>
                  <textarea
                    value={productForm.description}
                    onChange={(e) =>
                      setProductForm({ ...productForm, description: e.target.value })
                    }
                    rows={3}
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                    placeholder="Ürün açıklaması (opsiyonel)"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {t('menu.selectCategory')}
                  </label>
                  <select
                    value={productForm.category_id}
                    onChange={(e) =>
                      setProductForm({ ...productForm, category_id: e.target.value })
                    }
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="">{t('menu.selectCategory')}</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">
                      {t('menu.productPrice')}
                    </label>
                    <input
                      type="number"
                      value={productForm.price}
                      onChange={(e) =>
                        setProductForm({ ...productForm, price: e.target.value })
                      }
                      className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                      placeholder="0"
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">
                      {t('menu.preparationTime')}
                    </label>
                    <input
                      type="number"
                      value={productForm.preparation_time}
                      onChange={(e) =>
                        setProductForm({
                          ...productForm,
                          preparation_time: e.target.value,
                        })
                      }
                      className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                      placeholder="20"
                      min="0"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {t('menu.productImage')}
                  </label>
                  <input
                    type="url"
                    value={productForm.image_url}
                    onChange={(e) =>
                      setProductForm({ ...productForm, image_url: e.target.value })
                    }
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="https://..."
                  />
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="is_available"
                    checked={productForm.is_available}
                    onChange={(e) =>
                      setProductForm({
                        ...productForm,
                        is_available: e.target.checked,
                      })
                    }
                    className="w-5 h-5 rounded bg-gray-700 border-gray-600 text-orange-500 focus:ring-orange-500"
                  />
                  <label htmlFor="is_available" className="text-gray-300">
                    {t('menu.isAvailable')}
                  </label>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowAddProduct(false);
                    setEditingProduct(null);
                  }}
                  className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-xl transition-colors"
                >
                  {t('common.cancel')}
                </button>
                <button
                  onClick={handleSaveProduct}
                  disabled={
                    !productForm.name.trim() ||
                    !productForm.price ||
                    !productForm.category_id
                  }
                  className="flex-1 py-3 bg-orange-500 hover:bg-orange-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-xl transition-colors"
                >
                  {t('common.save')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
