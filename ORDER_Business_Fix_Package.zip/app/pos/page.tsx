'use client';

import { useState, useEffect } from 'react';
import { useVenueStore, useTableStore, useOrderStore } from '@/stores';
import { useOrders, useTables } from '@/hooks/useSupabase';
import { t } from '@/translations/tr';
import {
  CreditCard,
  Banknote,
  Wallet,
  Receipt,
  Percent,
  Split,
  Printer,
  X,
  Check,
  QrCode,
  Smartphone,
  Gift,
  Minus,
  Plus,
  AlertCircle,
  RefreshCw,
  Building,
} from 'lucide-react';
import type { Order, PaymentMethod as PaymentMethodType } from '@/types/database';

type PaymentMethod = 'cash' | 'card' | 'tit_pay' | 'multinet' | 'sodexo' | 'ticket' | 'mobile';

const paymentMethods: { id: PaymentMethod; name: string; icon: any; color?: string }[] = [
  { id: 'cash', name: t('pos.cash'), icon: Banknote },
  { id: 'card', name: t('pos.card'), icon: CreditCard },
  { id: 'tit_pay', name: t('pos.titPay'), icon: QrCode, color: 'from-purple-500 to-indigo-500' },
  { id: 'multinet', name: t('pos.multinet'), icon: Wallet },
  { id: 'sodexo', name: t('pos.sodexo'), icon: Wallet },
  { id: 'ticket', name: t('pos.ticket'), icon: Gift },
  { id: 'mobile', name: t('pos.mobilePayment'), icon: Smartphone },
];

export default function POSPage() {
  const { currentVenue, currentVenueId, venues } = useVenueStore();
  const { updateTable } = useTables(currentVenueId);
  const {
    orders,
    isLoading,
    completePayment,
    refetch,
  } = useOrders(currentVenueId, {
    status: ['pending', 'confirmed', 'preparing', 'ready', 'served'],
  });

  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showDiscountModal, setShowDiscountModal] = useState(false);
  const [showSplitModal, setShowSplitModal] = useState(false);
  const [mounted, setMounted] = useState(false);

  // Discount state for selected order
  const [orderDiscounts, setOrderDiscounts] = useState<Record<string, { amount: number; type: 'percent' | 'amount' }>>({});

  useEffect(() => {
    setMounted(true);
  }, []);

  // Filter unpaid orders
  const unpaidOrders = orders.filter((o) => o.payment_status !== 'paid');

  // Group by type
  const tableOrders = unpaidOrders.filter((o) => o.type === 'dine_in');
  const otherOrders = unpaidOrders.filter((o) => o.type !== 'dine_in');

  // Calculate totals
  const totalRevenue = unpaidOrders.reduce((sum, o) => sum + o.total, 0);

  const handleApplyDiscount = (type: 'percent' | 'amount', value: number) => {
    if (!selectedOrder) return;

    setOrderDiscounts((prev) => ({
      ...prev,
      [selectedOrder.id]: { amount: value, type },
    }));
    setShowDiscountModal(false);
  };

  const getOrderTotal = (order: Order) => {
    const discount = orderDiscounts[order.id];
    if (!discount || discount.amount === 0) return order.total;

    const discountAmount =
      discount.type === 'percent'
        ? (order.subtotal * discount.amount) / 100
        : discount.amount;

    return Math.max(0, order.total - discountAmount);
  };

  const handlePayment = async (method: PaymentMethod, amount: number) => {
    if (!selectedOrder) return;

    try {
      await completePayment(selectedOrder.id, method, amount);

      // Update table status if dine_in
      if (selectedOrder.table_id) {
        await updateTable(selectedOrder.table_id, { status: 'cleaning' });
      }

      setSelectedOrder(null);
      setShowPaymentModal(false);
      alert(`${t('pos.paymentReceived')}\n${paymentMethods.find((m) => m.id === method)?.name}: ₺${amount}`);
    } catch (err) {
      console.error('Ödeme hatası:', err);
    }
  };

  if (!mounted) {
    return <div className="animate-pulse bg-gray-800 rounded-2xl h-96" />;
  }

  if (!currentVenue) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">{t('messages.selectVenue')}</h2>
          <p className="text-gray-400">POS için bir mekan seçin.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-6 h-[calc(100vh-120px)]">
      {/* Left: Open Checks */}
      <div className="w-80 flex-shrink-0 flex flex-col">
        <div className="bg-gray-800 rounded-2xl border border-gray-700 flex-1 flex flex-col overflow-hidden">
          <div className="p-4 border-b border-gray-700 flex items-center justify-between">
            <div>
              <h2 className="font-semibold text-white">{t('pos.openChecks')}</h2>
              <p className="text-sm text-gray-400">
                {unpaidOrders.length} hesap • ₺{totalRevenue.toLocaleString()}
              </p>
            </div>
            <button
              onClick={refetch}
              className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
            >
              <RefreshCw className={`w-4 h-4 text-gray-400 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="p-4 text-center text-gray-500">{t('common.loading')}</div>
            ) : unpaidOrders.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <Receipt className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>{t('common.noData')}</p>
              </div>
            ) : (
              <>
                {/* Table Orders */}
                {tableOrders.length > 0 && (
                  <div className="p-2">
                    <p className="text-xs font-medium text-gray-500 px-2 py-1">
                      MASALAR ({tableOrders.length})
                    </p>
                    {tableOrders.map((order) => (
                      <OrderButton
                        key={order.id}
                        order={order}
                        isSelected={selectedOrder?.id === order.id}
                        onClick={() => setSelectedOrder(order)}
                        getTotal={getOrderTotal}
                      />
                    ))}
                  </div>
                )}

                {/* Other Orders */}
                {otherOrders.length > 0 && (
                  <div className="p-2 border-t border-gray-700">
                    <p className="text-xs font-medium text-gray-500 px-2 py-1">
                      PAKET / TESLİMAT ({otherOrders.length})
                    </p>
                    {otherOrders.map((order) => (
                      <OrderButton
                        key={order.id}
                        order={order}
                        isSelected={selectedOrder?.id === order.id}
                        onClick={() => setSelectedOrder(order)}
                        getTotal={getOrderTotal}
                      />
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Center: Order Detail */}
      <div className="flex-1 flex flex-col">
        {selectedOrder ? (
          <OrderDetail
            order={selectedOrder}
            discount={orderDiscounts[selectedOrder.id]}
            getTotal={getOrderTotal}
          />
        ) : (
          <div className="bg-gray-800 rounded-2xl border border-gray-700 flex-1 flex items-center justify-center">
            <div className="text-center">
              <Receipt className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-500">{t('pos.selectCheck')}</p>
            </div>
          </div>
        )}
      </div>

      {/* Right: Actions */}
      <div className="w-72 flex-shrink-0 space-y-4">
        {/* Quick Stats */}
        <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl p-4 text-white">
          <p className="text-orange-100 text-sm">{t('pos.todayTotal')}</p>
          <p className="text-3xl font-bold">₺{totalRevenue.toLocaleString()}</p>
          <div className="flex items-center gap-4 mt-2 text-sm text-orange-100">
            <span>{unpaidOrders.length} {t('pos.open')}</span>
          </div>
        </div>

        {/* Actions */}
        {selectedOrder && (
          <div className="bg-gray-800 rounded-2xl border border-gray-700 p-4 space-y-3">
            <button
              onClick={() => setShowPaymentModal(true)}
              className="w-full py-4 bg-green-500 hover:bg-green-600 text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-colors"
            >
              <CreditCard className="w-5 h-5" />
              {t('pos.takePayment')}
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setShowDiscountModal(true)}
                className="py-3 bg-gray-700 hover:bg-gray-600 rounded-xl font-medium text-white flex items-center justify-center gap-1 transition-colors"
              >
                <Percent className="w-4 h-4" />
                {t('pos.applyDiscount')}
              </button>
              <button
                onClick={() => setShowSplitModal(true)}
                className="py-3 bg-gray-700 hover:bg-gray-600 rounded-xl font-medium text-white flex items-center justify-center gap-1 transition-colors"
              >
                <Split className="w-4 h-4" />
                {t('pos.splitBill')}
              </button>
            </div>

            <button className="w-full py-3 border border-gray-600 rounded-xl font-medium text-gray-300 flex items-center justify-center gap-2 hover:bg-gray-700 transition-colors">
              <Printer className="w-4 h-4" />
              {t('pos.printPreBill')}
            </button>
          </div>
        )}

        {/* Payment Methods Quick Access */}
        <div className="bg-gray-800 rounded-2xl border border-gray-700 p-4">
          <p className="text-sm font-medium text-gray-400 mb-3">{t('pos.quickPayment')}</p>
          <div className="grid grid-cols-3 gap-2">
            {paymentMethods.slice(0, 6).map((method) => (
              <button
                key={method.id}
                onClick={() => selectedOrder && setShowPaymentModal(true)}
                disabled={!selectedOrder}
                className="p-3 bg-gray-700 hover:bg-gray-600 rounded-xl text-center transition-colors disabled:opacity-50"
              >
                <method.icon className="w-5 h-5 mx-auto text-gray-400 mb-1" />
                <p className="text-xs text-gray-400">{method.name}</p>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && selectedOrder && (
        <PaymentModal
          order={selectedOrder}
          total={getOrderTotal(selectedOrder)}
          onPay={handlePayment}
          onClose={() => setShowPaymentModal(false)}
        />
      )}

      {/* Discount Modal */}
      {showDiscountModal && selectedOrder && (
        <DiscountModal
          currentDiscount={orderDiscounts[selectedOrder.id]?.amount || 0}
          currentType={orderDiscounts[selectedOrder.id]?.type || 'percent'}
          onApply={handleApplyDiscount}
          onClose={() => setShowDiscountModal(false)}
        />
      )}

      {/* Split Modal */}
      {showSplitModal && selectedOrder && (
        <SplitModal
          total={getOrderTotal(selectedOrder)}
          onClose={() => setShowSplitModal(false)}
        />
      )}
    </div>
  );
}

// Order Button Component
function OrderButton({
  order,
  isSelected,
  onClick,
  getTotal,
}: {
  order: Order;
  isSelected: boolean;
  onClick: () => void;
  getTotal: (order: Order) => number;
}) {
  const duration = Math.floor(
    (Date.now() - new Date(order.created_at).getTime()) / 60000
  );

  return (
    <button
      onClick={onClick}
      className={`w-full p-3 rounded-xl mb-1 text-left transition-all ${
        isSelected
          ? 'bg-orange-500/20 border-2 border-orange-500'
          : 'bg-gray-700 hover:bg-gray-600 border-2 border-transparent'
      }`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-lg flex items-center justify-center ${
              order.type === 'dine_in' ? 'bg-red-500/20' : 'bg-purple-500/20'
            }`}
          >
            {order.type === 'dine_in' ? (
              <span className="font-bold text-red-400">#{order.table_number}</span>
            ) : (
              <Building className="w-5 h-5 text-purple-400" />
            )}
          </div>
          <div>
            <p className="font-medium text-white">
              {order.type === 'dine_in'
                ? `Masa ${order.table_number}`
                : order.order_number}
            </p>
            <p className="text-xs text-gray-400">
              {order.waiter_name || 'Garson'} • {duration} dk
            </p>
          </div>
        </div>
        <p className="font-bold text-white">₺{getTotal(order).toLocaleString()}</p>
      </div>
    </button>
  );
}

// Order Detail Component
function OrderDetail({
  order,
  discount,
  getTotal,
}: {
  order: Order;
  discount?: { amount: number; type: 'percent' | 'amount' };
  getTotal: (order: Order) => number;
}) {
  const items = order.items as any[];
  const discountAmount = discount
    ? discount.type === 'percent'
      ? (order.subtotal * discount.amount) / 100
      : discount.amount
    : 0;

  return (
    <div className="bg-gray-800 rounded-2xl border border-gray-700 flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-gray-700 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">
            {order.type === 'dine_in'
              ? `Masa ${order.table_number}`
              : order.order_number}
          </h2>
          <p className="text-sm text-gray-400">
            {order.waiter_name || 'Garson'} • {t('orders.orderItems')}: {items.length}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-700 rounded-lg">
            <Printer className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Items */}
      <div className="flex-1 overflow-y-auto p-4">
        <table className="w-full">
          <thead>
            <tr className="text-left text-sm text-gray-500 border-b border-gray-700">
              <th className="pb-2">{t('menu.productName')}</th>
              <th className="pb-2 text-center">{t('common.quantity')}</th>
              <th className="pb-2 text-right">{t('common.price')}</th>
              <th className="pb-2 text-right">{t('common.total')}</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item: any) => (
              <tr key={item.id} className="border-b border-gray-700/50">
                <td className="py-3">
                  <p className="font-medium text-white">{item.product_name}</p>
                  {item.notes && (
                    <p className="text-xs text-gray-500">{item.notes}</p>
                  )}
                </td>
                <td className="py-3 text-center text-gray-400">{item.quantity}</td>
                <td className="py-3 text-right text-gray-400">₺{item.unit_price}</td>
                <td className="py-3 text-right font-medium text-white">
                  ₺{item.total_price}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals */}
      <div className="p-4 bg-gray-900 border-t border-gray-700">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">{t('common.subtotal')}</span>
            <span className="text-white">₺{order.subtotal.toLocaleString()}</span>
          </div>
          {discountAmount > 0 && (
            <div className="flex justify-between text-sm text-green-400">
              <span>
                {t('common.discount')} (
                {discount?.type === 'percent' ? `%${discount.amount}` : `₺${discount?.amount}`})
              </span>
              <span>-₺{discountAmount.toLocaleString()}</span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">{t('common.tax')} (%8)</span>
            <span className="text-white">₺{order.tax.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-xl font-bold pt-2 border-t border-gray-700">
            <span className="text-white">{t('common.total')}</span>
            <span className="text-orange-500">₺{getTotal(order).toLocaleString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// Payment Modal
function PaymentModal({
  order,
  total,
  onPay,
  onClose,
}: {
  order: Order;
  total: number;
  onPay: (method: PaymentMethod, amount: number) => void;
  onClose: () => void;
}) {
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('cash');
  const [cashReceived, setCashReceived] = useState<string>('');
  const [paymentMode, setPaymentMode] = useState<'full' | 'partial' | 'split'>('full');
  const [splitCount, setSplitCount] = useState(2);
  const [partialAmount, setPartialAmount] = useState<string>('');

  const cashAmount = parseFloat(cashReceived) || 0;
  const change = cashAmount - total;
  const splitAmount = Math.ceil(total / splitCount);
  const partial = parseFloat(partialAmount) || 0;

  const quickAmounts = [50, 100, 200, 500, 1000, 2000];

  const getPayAmount = () => {
    if (paymentMode === 'partial') return partial;
    if (paymentMode === 'split') return splitAmount;
    return total;
  };

  const canPay = () => {
    if (paymentMode === 'partial') return partial > 0 && partial <= total;
    if (paymentMode === 'split') return splitCount >= 2;
    if (selectedMethod === 'cash') return cashAmount >= total;
    return true;
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-700 flex items-center justify-between sticky top-0 bg-gray-800">
          <div>
            <h2 className="text-xl font-bold text-white">{t('pos.takePayment')}</h2>
            <p className="text-gray-400">
              {order.type === 'dine_in' ? `Masa ${order.table_number}` : order.order_number}
            </p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-700 rounded-lg">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Total */}
          <div className="text-center">
            <p className="text-gray-400">{t('common.total')}</p>
            <p className="text-4xl font-bold text-white">₺{total.toLocaleString()}</p>
          </div>

          {/* Payment Mode Tabs */}
          <div className="flex gap-2 p-1 bg-gray-700 rounded-xl">
            <button
              onClick={() => setPaymentMode('full')}
              className={`flex-1 py-2 rounded-lg font-medium transition-colors ${
                paymentMode === 'full' ? 'bg-gray-600 text-white' : 'text-gray-400'
              }`}
            >
              {t('pos.fullPayment')}
            </button>
            <button
              onClick={() => setPaymentMode('partial')}
              className={`flex-1 py-2 rounded-lg font-medium transition-colors ${
                paymentMode === 'partial' ? 'bg-gray-600 text-white' : 'text-gray-400'
              }`}
            >
              {t('pos.partialPayment')}
            </button>
            <button
              onClick={() => setPaymentMode('split')}
              className={`flex-1 py-2 rounded-lg font-medium transition-colors ${
                paymentMode === 'split' ? 'bg-gray-600 text-white' : 'text-gray-400'
              }`}
            >
              {t('pos.splitBill')}
            </button>
          </div>

          {/* Partial Amount Input */}
          {paymentMode === 'partial' && (
            <div>
              <p className="text-sm font-medium text-gray-400 mb-2">{t('common.total')}</p>
              <input
                type="number"
                value={partialAmount}
                onChange={(e) => setPartialAmount(e.target.value)}
                placeholder="0"
                max={total}
                className="w-full text-2xl font-bold text-center py-4 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
          )}

          {/* Split Options */}
          {paymentMode === 'split' && (
            <div>
              <p className="text-sm font-medium text-gray-400 mb-2">{t('pos.numberOfPeople')}</p>
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={() => setSplitCount(Math.max(2, splitCount - 1))}
                  className="w-12 h-12 bg-gray-700 hover:bg-gray-600 rounded-xl font-bold text-xl text-white"
                >
                  -
                </button>
                <span className="text-4xl font-bold text-white w-16 text-center">
                  {splitCount}
                </span>
                <button
                  onClick={() => setSplitCount(Math.min(10, splitCount + 1))}
                  className="w-12 h-12 bg-gray-700 hover:bg-gray-600 rounded-xl font-bold text-xl text-white"
                >
                  +
                </button>
              </div>
              <div className="mt-4 p-4 bg-blue-500/20 rounded-xl text-center">
                <p className="text-blue-400">{t('pos.perPerson')}</p>
                <p className="text-2xl font-bold text-blue-300">₺{splitAmount.toLocaleString()}</p>
              </div>
            </div>
          )}

          {/* Payment Methods */}
          <div>
            <p className="text-sm font-medium text-gray-400 mb-2">{t('pos.paymentMethod')}</p>
            <div className="grid grid-cols-4 gap-2">
              {paymentMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setSelectedMethod(method.id)}
                  className={`p-3 rounded-xl text-center transition-all ${
                    selectedMethod === method.id
                      ? method.color
                        ? `bg-gradient-to-br ${method.color} text-white`
                        : 'bg-orange-500 text-white'
                      : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                  }`}
                >
                  <method.icon className="w-5 h-5 mx-auto mb-1" />
                  <p className="text-xs font-medium">{method.name}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Cash Input */}
          {selectedMethod === 'cash' && paymentMode === 'full' && (
            <div>
              <p className="text-sm font-medium text-gray-400 mb-2">{t('pos.amountReceived')}</p>
              <input
                type="number"
                value={cashReceived}
                onChange={(e) => setCashReceived(e.target.value)}
                placeholder="0"
                className="w-full text-3xl font-bold text-center py-4 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <div className="grid grid-cols-6 gap-2 mt-3">
                {quickAmounts.map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setCashReceived(amount.toString())}
                    className="py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-sm font-medium text-white"
                  >
                    {amount}
                  </button>
                ))}
              </div>
              {cashAmount >= total && (
                <div className="mt-4 p-4 bg-green-500/20 rounded-xl text-center">
                  <p className="text-green-400">{t('pos.change')}</p>
                  <p className="text-2xl font-bold text-green-300">₺{change.toFixed(2)}</p>
                </div>
              )}
            </div>
          )}

          {/* TiT Pay QR */}
          {selectedMethod === 'tit_pay' && (
            <div className="p-6 bg-gradient-to-br from-purple-500/20 to-indigo-500/20 rounded-xl text-center">
              <div className="w-32 h-32 bg-white rounded-xl mx-auto mb-4 flex items-center justify-center shadow-sm">
                <QrCode className="w-24 h-24 text-purple-600" />
              </div>
              <p className="font-medium text-purple-300">TiT Pay ile Ödeme</p>
              <p className="text-sm text-purple-400">QR kodu müşteriye gösterin</p>
            </div>
          )}

          {/* Pay Button */}
          <button
            onClick={() => onPay(selectedMethod, getPayAmount())}
            disabled={!canPay()}
            className="w-full py-4 bg-green-500 hover:bg-green-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-colors"
          >
            <Check className="w-5 h-5" />
            {t('pos.paymentComplete')}
          </button>
        </div>
      </div>
    </div>
  );
}

// Discount Modal
function DiscountModal({
  currentDiscount,
  currentType,
  onApply,
  onClose,
}: {
  currentDiscount: number;
  currentType: 'percent' | 'amount';
  onApply: (type: 'percent' | 'amount', value: number) => void;
  onClose: () => void;
}) {
  const [type, setType] = useState<'percent' | 'amount'>(currentType);
  const [value, setValue] = useState(currentDiscount.toString());

  const quickPercents = [5, 10, 15, 20, 25, 50];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-2xl w-full max-w-sm">
        <div className="p-6 border-b border-gray-700 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">{t('pos.applyDiscount')}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-700 rounded-lg">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Type Toggle */}
          <div className="flex bg-gray-700 rounded-lg p-1">
            <button
              onClick={() => setType('percent')}
              className={`flex-1 py-2 rounded-md font-medium transition-colors ${
                type === 'percent' ? 'bg-gray-600 text-white' : 'text-gray-400'
              }`}
            >
              {t('pos.discountPercent')}
            </button>
            <button
              onClick={() => setType('amount')}
              className={`flex-1 py-2 rounded-md font-medium transition-colors ${
                type === 'amount' ? 'bg-gray-600 text-white' : 'text-gray-400'
              }`}
            >
              {t('pos.discountAmount')}
            </button>
          </div>

          {/* Input */}
          <div className="relative">
            <input
              type="number"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="0"
              className="w-full text-3xl font-bold text-center py-4 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-2xl text-gray-500">
              {type === 'percent' ? '%' : '₺'}
            </span>
          </div>

          {/* Quick Percents */}
          {type === 'percent' && (
            <div className="grid grid-cols-6 gap-2">
              {quickPercents.map((p) => (
                <button
                  key={p}
                  onClick={() => setValue(p.toString())}
                  className="py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-sm font-medium text-white"
                >
                  %{p}
                </button>
              ))}
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <button
              onClick={() => onApply(type, 0)}
              className="flex-1 py-3 border border-gray-600 rounded-xl font-medium text-gray-300 hover:bg-gray-700"
            >
              {t('pos.removeDiscount')}
            </button>
            <button
              onClick={() => onApply(type, parseFloat(value) || 0)}
              className="flex-1 py-3 bg-orange-500 text-white rounded-xl font-medium hover:bg-orange-600"
            >
              {t('common.save')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Split Modal
function SplitModal({ total, onClose }: { total: number; onClose: () => void }) {
  const [splitCount, setSplitCount] = useState(2);
  const perPerson = Math.ceil(total / splitCount);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-2xl w-full max-w-sm">
        <div className="p-6 border-b border-gray-700 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">{t('pos.splitBill')}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-700 rounded-lg">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="text-center">
            <p className="text-gray-400">{t('common.total')}</p>
            <p className="text-3xl font-bold text-white">₺{total.toLocaleString()}</p>
          </div>

          <div>
            <p className="text-sm font-medium text-gray-400 mb-2">{t('pos.numberOfPeople')}</p>
            <div className="flex items-center justify-center gap-4">
              <button
                onClick={() => setSplitCount(Math.max(2, splitCount - 1))}
                className="w-12 h-12 bg-gray-700 hover:bg-gray-600 rounded-xl flex items-center justify-center"
              >
                <Minus className="w-5 h-5 text-white" />
              </button>
              <span className="text-4xl font-bold text-white w-16 text-center">
                {splitCount}
              </span>
              <button
                onClick={() => setSplitCount(splitCount + 1)}
                className="w-12 h-12 bg-gray-700 hover:bg-gray-600 rounded-xl flex items-center justify-center"
              >
                <Plus className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>

          <div className="bg-orange-500/20 rounded-xl p-4 text-center">
            <p className="text-orange-400">{t('pos.perPerson')}</p>
            <p className="text-3xl font-bold text-orange-300">₺{perPerson.toLocaleString()}</p>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 bg-orange-500 text-white rounded-xl font-medium hover:bg-orange-600"
          >
            {t('common.confirm')}
          </button>
        </div>
      </div>
    </div>
  );
}
