// =============================================
// ORDER BUSINESS - SUPABASE CLIENT
// Customer App ile %100 uyumlu
// =============================================

import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/database';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Supabase environment variables eksik!');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});

// =============================================
// HELPER FUNCTIONS
// =============================================

// Venue bazlı veri çekme
export async function fetchByVenue<T>(
  table: string,
  venueId: string,
  options?: {
    select?: string;
    orderBy?: string;
    ascending?: boolean;
    filters?: Record<string, any>;
  }
): Promise<{ data: T[] | null; error: any }> {
  let query = supabase
    .from(table)
    .select(options?.select || '*')
    .eq('venue_id', venueId);

  if (options?.filters) {
    Object.entries(options.filters).forEach(([key, value]) => {
      query = query.eq(key, value);
    });
  }

  if (options?.orderBy) {
    query = query.order(options.orderBy, { ascending: options.ascending ?? true });
  }

  const { data, error } = await query;
  return { data: data as T[] | null, error };
}

// Real-time subscription helper
export function subscribeToTable(
  table: string,
  venueId: string,
  callback: (payload: any) => void
) {
  const channel = supabase
    .channel(`${table}-${venueId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: table,
        filter: `venue_id=eq.${venueId}`,
      },
      callback
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}

// Auth helpers
export async function getCurrentUser() {
  const { data: { user }, error } = await supabase.auth.getUser();
  return { user, error };
}

export async function signInWithPin(email: string, pin: string) {
  // Staff PIN login için custom logic
  const { data, error } = await supabase
    .from('staff')
    .select('*, venues(*)')
    .eq('email', email)
    .eq('pin_code', pin)
    .eq('is_active', true)
    .single();

  return { data, error };
}

export async function signOut() {
  return await supabase.auth.signOut();
}

export default supabase;
