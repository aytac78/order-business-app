'use client';

import { useState, useEffect } from 'react';
import { useVenueStore, useTableStore } from '@/stores';
import { useTables } from '@/hooks/useSupabase';
import { t } from '@/translations/tr';
import {
  Plus,
  RefreshCw,
  Users,
  Clock,
  Edit2,
  Trash2,
  AlertCircle,
  Circle,
  Square,
  RectangleHorizontal,
  Filter,
  MoreVertical,
  Utensils,
  CalendarCheck,
  SprayCan,
} from 'lucide-react';
import type { Table, TableStatus, TableShape } from '@/types/database';

const statusConfig: Record<
  TableStatus,
  { label: string; color: string; bgColor: string; icon: any }
> = {
  available: {
    label: t('tables.available'),
    color: 'text-green-400',
    bgColor: 'bg-green-500/20 border-green-500/50',
    icon: Circle,
  },
  occupied: {
    label: t('tables.occupied'),
    color: 'text-red-400',
    bgColor: 'bg-red-500/20 border-red-500/50',
    icon: Utensils,
  },
  reserved: {
    label: t('tables.reserved'),
    color: 'text-amber-400',
    bgColor: 'bg-amber-500/20 border-amber-500/50',
    icon: CalendarCheck,
  },
  cleaning: {
    label: t('tables.cleaning'),
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/20 border-purple-500/50',
    icon: SprayCan,
  },
};

const shapeIcons: Record<TableShape, any> = {
  square: Square,
  round: Circle,
  rectangle: RectangleHorizontal,
};

export default function TablesPage() {
  const { currentVenue, currentVenueId } = useVenueStore();
  const { setTables: setStoreTables } = useTableStore();
  const {
    tables,
    isLoading,
    error,
    stats,
    sections,
    createTable,
    updateTable,
    deleteTable,
    refetch,
  } = useTables(currentVenueId);

  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<TableStatus | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingTable, setEditingTable] = useState<Table | null>(null);

  // Form state
  const [form, setForm] = useState({
    number: '',
    name: '',
    capacity: '4',
    section: 'İç Mekan',
    shape: 'square' as TableShape,
  });

  // Sync with store
  useEffect(() => {
    setStoreTables(tables);
  }, [tables, setStoreTables]);

  // Reset form
  useEffect(() => {
    if (!showAddModal && !editingTable) {
      setForm({
        number: '',
        name: '',
        capacity: '4',
        section: selectedSection || 'İç Mekan',
        shape: 'square',
      });
    }
  }, [showAddModal, editingTable, selectedSection]);

  // Set form when editing
  useEffect(() => {
    if (editingTable) {
      setForm({
        number: editingTable.number,
        name: editingTable.name || '',
        capacity: editingTable.capacity.toString(),
        section: editingTable.section || 'İç Mekan',
        shape: editingTable.shape,
      });
    }
  }, [editingTable]);

  // Filter tables
  const filteredTables = tables.filter((table) => {
    if (selectedSection && table.section !== selectedSection) return false;
    if (statusFilter && table.status !== statusFilter) return false;
    return true;
  });

  // Handlers
  const handleSaveTable = async () => {
    if (!currentVenueId || !form.number.trim()) return;

    try {
      const tableData = {
        venue_id: currentVenueId,
        number: form.number,
        name: form.name || undefined,
        capacity: parseInt(form.capacity),
        section: form.section,
        shape: form.shape,
        status: 'available' as TableStatus,
        is_active: true,
      };

      if (editingTable) {
        await updateTable(editingTable.id, tableData);
      } else {
        await createTable(tableData);
      }
      setShowAddModal(false);
      setEditingTable(null);
    } catch (err) {
      console.error('Masa kaydetme hatası:', err);
    }
  };

  const handleDeleteTable = async (id: string) => {
    if (!confirm(t('messages.confirmDelete'))) return;
    try {
      await deleteTable(id);
    } catch (err) {
      console.error('Masa silme hatası:', err);
    }
  };

  const handleStatusChange = async (id: string, status: TableStatus) => {
    try {
      await updateTable(id, { status });
    } catch (err) {
      console.error('Durum güncelleme hatası:', err);
    }
  };

  // No venue selected
  if (!currentVenue) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">{t('messages.selectVenue')}</h2>
          <p className="text-gray-400">Masa yönetimi için bir mekan seçin.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">{t('tables.title')}</h1>
          <p className="text-gray-400">{stats.total} {t('tables.totalTables')}</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={refetch}
            className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <RefreshCw className={`w-5 h-5 text-gray-400 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white rounded-lg flex items-center gap-2 transition-colors"
          >
            <Plus className="w-5 h-5" />
            {t('tables.addTable')}
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-4">
        {Object.entries(statusConfig).map(([status, config]) => {
          const count = stats[status as keyof typeof stats] || 0;
          const StatusIcon = config.icon;
          return (
            <button
              key={status}
              onClick={() =>
                setStatusFilter(statusFilter === status ? null : (status as TableStatus))
              }
              className={`p-4 rounded-xl border-2 transition-all ${
                statusFilter === status
                  ? config.bgColor
                  : 'bg-gray-800 border-gray-700 hover:border-gray-600'
              }`}
            >
              <div className="flex items-center gap-3">
                <StatusIcon className={`w-5 h-5 ${config.color}`} />
                <div className="text-left">
                  <p className={`text-2xl font-bold ${config.color}`}>{count}</p>
                  <p className="text-sm text-gray-400">{config.label}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Section Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => setSelectedSection(null)}
          className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
            selectedSection === null
              ? 'bg-orange-500 text-white'
              : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
          }`}
        >
          {t('tables.allSections')} ({tables.length})
        </button>
        {sections.map((section) => {
          const count = tables.filter((t) => t.section === section).length;
          return (
            <button
              key={section}
              onClick={() => setSelectedSection(section)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                selectedSection === section
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              {section} ({count})
            </button>
          );
        })}
      </div>

      {/* Tables Grid */}
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">{t('common.loading')}</div>
        </div>
      ) : filteredTables.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 text-gray-500">
          <Users className="w-16 h-16 mb-4 opacity-50" />
          <p>{t('tables.noTables')}</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filteredTables.map((table) => {
            const config = statusConfig[table.status];
            const ShapeIcon = shapeIcons[table.shape];

            return (
              <div
                key={table.id}
                className={`relative group p-4 rounded-xl border-2 transition-all cursor-pointer ${config.bgColor}`}
              >
                {/* Table Number */}
                <div className="text-center mb-3">
                  <div
                    className={`inline-flex items-center justify-center w-12 h-12 rounded-xl ${
                      table.status === 'available'
                        ? 'bg-green-500'
                        : table.status === 'occupied'
                        ? 'bg-red-500'
                        : table.status === 'reserved'
                        ? 'bg-amber-500'
                        : 'bg-purple-500'
                    }`}
                  >
                    <span className="text-white font-bold text-lg">
                      {table.number}
                    </span>
                  </div>
                </div>

                {/* Table Info */}
                <div className="text-center">
                  {table.name && (
                    <p className="text-sm text-white font-medium mb-1">{table.name}</p>
                  )}
                  <div className="flex items-center justify-center gap-2 text-gray-400 text-sm">
                    <Users className="w-4 h-4" />
                    <span>{table.capacity}</span>
                    <ShapeIcon className="w-4 h-4 ml-2" />
                  </div>
                  <p className={`text-xs mt-2 ${config.color}`}>{config.label}</p>
                </div>

                {/* Hover Actions */}
                <div className="absolute inset-0 bg-black/70 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                  {/* Status Change Buttons */}
                  <div className="flex gap-1">
                    {Object.entries(statusConfig).map(([status, cfg]) => {
                      if (status === table.status) return null;
                      const Icon = cfg.icon;
                      return (
                        <button
                          key={status}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleStatusChange(table.id, status as TableStatus);
                          }}
                          className={`p-2 rounded-lg ${cfg.bgColor} transition-colors`}
                          title={cfg.label}
                        >
                          <Icon className={`w-4 h-4 ${cfg.color}`} />
                        </button>
                      );
                    })}
                  </div>

                  {/* Edit/Delete */}
                  <div className="flex gap-1 mt-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingTable(table);
                      }}
                      className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-4 h-4 text-white" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteTable(table.id);
                      }}
                      className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-red-400" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Modal */}
      {(showAddModal || editingTable) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-2xl w-full max-w-md p-6">
            <h2 className="text-xl font-bold text-white mb-4">
              {editingTable ? t('tables.editTable') : t('tables.addTable')}
            </h2>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {t('tables.tableNumber')}
                  </label>
                  <input
                    type="text"
                    value={form.number}
                    onChange={(e) => setForm({ ...form, number: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="1"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {t('tables.tableName')}
                  </label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="Pencere kenarı"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {t('tables.capacity')}
                  </label>
                  <select
                    value={form.capacity}
                    onChange={(e) => setForm({ ...form, capacity: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12].map((n) => (
                      <option key={n} value={n}>
                        {n} {t('common.quantity')}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {t('tables.section')}
                  </label>
                  <select
                    value={form.section}
                    onChange={(e) => setForm({ ...form, section: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="İç Mekan">{t('tables.indoor')}</option>
                    <option value="Teras">{t('tables.terrace')}</option>
                    <option value="Bahçe">{t('tables.garden')}</option>
                    <option value="VIP">{t('tables.vip')}</option>
                    <option value="Dış Mekan">{t('tables.outdoor')}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  {t('tables.shape')}
                </label>
                <div className="flex gap-3">
                  {(['square', 'round', 'rectangle'] as TableShape[]).map((shape) => {
                    const Icon = shapeIcons[shape];
                    return (
                      <button
                        key={shape}
                        type="button"
                        onClick={() => setForm({ ...form, shape })}
                        className={`flex-1 p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                          form.shape === shape
                            ? 'border-orange-500 bg-orange-500/20'
                            : 'border-gray-600 hover:border-gray-500'
                        }`}
                      >
                        <Icon
                          className={`w-6 h-6 ${
                            form.shape === shape ? 'text-orange-500' : 'text-gray-400'
                          }`}
                        />
                        <span
                          className={`text-xs ${
                            form.shape === shape ? 'text-orange-500' : 'text-gray-400'
                          }`}
                        >
                          {t(`tables.${shape}`)}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingTable(null);
                }}
                className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-xl transition-colors"
              >
                {t('common.cancel')}
              </button>
              <button
                onClick={handleSaveTable}
                disabled={!form.number.trim()}
                className="flex-1 py-3 bg-orange-500 hover:bg-orange-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-xl transition-colors"
              >
                {t('common.save')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
