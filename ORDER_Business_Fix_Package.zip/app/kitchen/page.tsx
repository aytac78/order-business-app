'use client';

import { useState, useEffect } from 'react';
import { useVenueStore, useOrderStore } from '@/stores';
import { useOrders } from '@/hooks/useSupabase';
import { t } from '@/translations/tr';
import {
  Clock,
  CheckCircle,
  AlertCircle,
  Bell,
  Volume2,
  VolumeX,
  RefreshCw,
  ChefHat,
  Flame,
  Play,
  Users,
} from 'lucide-react';
import type { Order, OrderItemJSON } from '@/types/database';

export default function KitchenPage() {
  const { currentVenue, currentVenueId } = useVenueStore();
  const { setOrders: setStoreOrders } = useOrderStore();
  const {
    orders,
    isLoading,
    updateOrderStatus,
    updateOrderItemStatus,
    refetch,
  } = useOrders(currentVenueId, {
    status: ['pending', 'confirmed', 'preparing', 'ready'],
  });

  const [soundEnabled, setSoundEnabled] = useState(true);
  const [mounted, setMounted] = useState(false);
  const [displayTime, setDisplayTime] = useState<string>('--:--:--');

  useEffect(() => {
    setMounted(true);
    const updateTime = () => {
      setDisplayTime(new Date().toLocaleTimeString('tr-TR'));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Sync with store
  useEffect(() => {
    setStoreOrders(orders);
  }, [orders, setStoreOrders]);

  // Handlers
  const handleStartOrder = async (orderId: string) => {
    try {
      await updateOrderStatus(orderId, 'preparing');
    } catch (err) {
      console.error('Sipariş başlatma hatası:', err);
    }
  };

  const handleItemReady = async (orderId: string, itemId: string) => {
    try {
      await updateOrderItemStatus(orderId, itemId, 'ready');
    } catch (err) {
      console.error('Ürün güncelleme hatası:', err);
    }
  };

  const handleCompleteOrder = async (orderId: string) => {
    try {
      await updateOrderStatus(orderId, 'ready');
    } catch (err) {
      console.error('Sipariş tamamlama hatası:', err);
    }
  };

  const handleServeOrder = async (orderId: string) => {
    try {
      await updateOrderStatus(orderId, 'served');
      if (soundEnabled) {
        // Bell sound
      }
    } catch (err) {
      console.error('Servis hatası:', err);
    }
  };

  // Categorize orders
  const pendingOrders = orders.filter(
    (o) => o.status === 'pending' || o.status === 'confirmed'
  );
  const preparingOrders = orders.filter((o) => o.status === 'preparing');
  const readyOrders = orders.filter((o) => o.status === 'ready');

  const typeLabels: Record<string, { text: string; color: string }> = {
    dine_in: { text: t('orders.dineIn'), color: 'bg-blue-600' },
    takeaway: { text: t('orders.takeaway'), color: 'bg-purple-600' },
    delivery: { text: t('orders.delivery'), color: 'bg-green-600' },
    qr_order: { text: t('orders.qrOrder'), color: 'bg-cyan-600' },
  };

  // Calculate time since order
  const getOrderDuration = (createdAt: string) => {
    const diff = Date.now() - new Date(createdAt).getTime();
    return Math.floor(diff / 60000); // minutes
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white text-xl">{t('common.loading')}</div>
      </div>
    );
  }

  if (!currentVenue) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">{t('messages.selectVenue')}</h2>
          <p className="text-gray-400">Mutfak ekranı için bir mekan seçin.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white -m-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <ChefHat className="w-8 h-8 text-orange-500" />
          <div>
            <h1 className="text-2xl font-bold">{t('kitchen.title')}</h1>
            <p className="text-gray-400 text-sm">{displayTime}</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* Stats */}
          <div className="flex items-center gap-6 bg-gray-800 rounded-xl px-6 py-3">
            <div className="text-center">
              <p className="text-2xl font-bold text-amber-500">{pendingOrders.length}</p>
              <p className="text-xs text-gray-400">{t('kitchen.pendingOrders')}</p>
            </div>
            <div className="w-px h-8 bg-gray-700" />
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-500">{preparingOrders.length}</p>
              <p className="text-xs text-gray-400">{t('kitchen.preparingOrders')}</p>
            </div>
            <div className="w-px h-8 bg-gray-700" />
            <div className="text-center">
              <p className="text-2xl font-bold text-green-500">{readyOrders.length}</p>
              <p className="text-xs text-gray-400">{t('kitchen.readyOrders')}</p>
            </div>
          </div>

          {/* Refresh */}
          <button
            onClick={refetch}
            className="p-3 bg-gray-800 hover:bg-gray-700 rounded-xl transition-colors"
          >
            <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-3 rounded-xl transition-colors ${
              soundEnabled ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-700 hover:bg-gray-600'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* BEKLEYEN */}
        <div className="bg-gray-800/50 rounded-2xl p-4">
          <div className="flex items-center gap-3 mb-4 pb-4 border-b border-gray-700">
            <div className="w-12 h-12 rounded-xl bg-amber-600 flex items-center justify-center">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{t('kitchen.pendingOrders')}</h2>
              <p className="text-sm text-gray-400">{pendingOrders.length} sipariş</p>
            </div>
          </div>

          <div className="space-y-4">
            {pendingOrders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                status="pending"
                typeLabels={typeLabels}
                getOrderDuration={getOrderDuration}
                onStart={() => handleStartOrder(order.id)}
              />
            ))}

            {pendingOrders.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Clock className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>{t('kitchen.noPending')}</p>
              </div>
            )}
          </div>
        </div>

        {/* HAZIRLANIYOR */}
        <div className="bg-gray-800/50 rounded-2xl p-4">
          <div className="flex items-center gap-3 mb-4 pb-4 border-b border-gray-700">
            <div className="w-12 h-12 rounded-xl bg-purple-600 flex items-center justify-center animate-pulse">
              <Flame className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{t('kitchen.preparingOrders')}</h2>
              <p className="text-sm text-gray-400">{preparingOrders.length} sipariş</p>
            </div>
          </div>

          <div className="space-y-4">
            {preparingOrders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                status="preparing"
                typeLabels={typeLabels}
                getOrderDuration={getOrderDuration}
                onItemReady={(itemId) => handleItemReady(order.id, itemId)}
                onComplete={() => handleCompleteOrder(order.id)}
              />
            ))}

            {preparingOrders.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Flame className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>{t('kitchen.noPreparing')}</p>
              </div>
            )}
          </div>
        </div>

        {/* HAZIR */}
        <div className="bg-gray-800/50 rounded-2xl p-4">
          <div className="flex items-center gap-3 mb-4 pb-4 border-b border-gray-700">
            <div className="w-12 h-12 rounded-xl bg-green-600 flex items-center justify-center animate-bounce">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{t('kitchen.readyOrders')}</h2>
              <p className="text-sm text-gray-400">{readyOrders.length} sipariş</p>
            </div>
          </div>

          <div className="space-y-4">
            {readyOrders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                status="ready"
                typeLabels={typeLabels}
                getOrderDuration={getOrderDuration}
                onServe={() => handleServeOrder(order.id)}
              />
            ))}

            {readyOrders.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <CheckCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>{t('kitchen.noReady')}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Order Card Component
function OrderCard({
  order,
  status,
  typeLabels,
  getOrderDuration,
  onStart,
  onItemReady,
  onComplete,
  onServe,
}: {
  order: Order;
  status: 'pending' | 'preparing' | 'ready';
  typeLabels: Record<string, { text: string; color: string }>;
  getOrderDuration: (date: string) => number;
  onStart?: () => void;
  onItemReady?: (itemId: string) => void;
  onComplete?: () => void;
  onServe?: () => void;
}) {
  const duration = getOrderDuration(order.created_at);
  const isUrgent = duration > 20;
  const items = order.items as OrderItemJSON[];

  const headerColors = {
    pending: 'bg-amber-600',
    preparing: 'bg-purple-600',
    ready: 'bg-green-600',
  };

  return (
    <div
      className={`rounded-xl overflow-hidden ${
        isUrgent && status !== 'ready'
          ? 'bg-red-900/50 border-2 border-red-500'
          : 'bg-gray-700'
      }`}
    >
      {/* Header */}
      <div className={`px-4 py-3 ${headerColors[status]} flex items-center justify-between`}>
        <div className="flex items-center gap-2">
          <span className="font-bold text-lg">{order.order_number}</span>
          {isUrgent && status !== 'ready' && (
            <Flame className="w-5 h-5 text-yellow-300" />
          )}
        </div>
        <div className="flex items-center gap-2">
          {order.table_number && (
            <span className="bg-white/20 px-2 py-1 rounded text-sm">
              Masa #{order.table_number}
            </span>
          )}
          <span className={`px-2 py-1 rounded text-sm ${typeLabels[order.type]?.color || 'bg-gray-600'}`}>
            {typeLabels[order.type]?.text || order.type}
          </span>
        </div>
      </div>

      {/* Items */}
      <div className="p-4 space-y-2">
        {items.map((item) => (
          <div
            key={item.id}
            onClick={() => {
              if (status === 'preparing' && item.status !== 'ready' && onItemReady) {
                onItemReady(item.id);
              }
            }}
            className={`flex items-center gap-3 p-2 rounded-lg transition-all ${
              item.status === 'ready'
                ? 'bg-green-600/50 line-through opacity-60'
                : status === 'preparing'
                ? 'bg-purple-600/30 hover:bg-purple-600/50 cursor-pointer'
                : status === 'ready'
                ? 'bg-green-600/30'
                : 'bg-gray-600/50'
            }`}
          >
            <span
              className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold ${
                item.status === 'ready'
                  ? 'bg-green-600'
                  : status === 'preparing'
                  ? 'bg-purple-600'
                  : status === 'ready'
                  ? 'bg-green-600'
                  : 'bg-amber-600'
              }`}
            >
              {item.status === 'ready' ? (
                <CheckCircle className="w-5 h-5" />
              ) : (
                item.quantity
              )}
            </span>
            <div className="flex-1">
              <p className="font-medium">{item.product_name}</p>
              {item.notes && (
                <p className="text-xs text-amber-400">⚠️ {item.notes}</p>
              )}
            </div>
            {status === 'preparing' && item.status !== 'ready' && (
              <span className="text-xs bg-white/10 px-2 py-1 rounded">
                {t('kitchen.clickToComplete')}
              </span>
            )}
            {status === 'ready' && (
              <span className="text-xs">x{item.quantity}</span>
            )}
          </div>
        ))}
      </div>

      {/* Duration */}
      <div className="px-4 pb-2">
        <div className="flex items-center gap-2 text-sm text-gray-400">
          <Clock className="w-4 h-4" />
          <span>{duration} dk</span>
          {order.waiter_name && (
            <>
              <span>•</span>
              <Users className="w-4 h-4" />
              <span>{order.waiter_name}</span>
            </>
          )}
        </div>
      </div>

      {/* Action */}
      <div className="p-4 pt-0">
        {status === 'pending' && onStart && (
          <button
            onClick={onStart}
            className="w-full py-3 bg-purple-600 hover:bg-purple-500 rounded-xl font-bold flex items-center justify-center gap-2"
          >
            <Play className="w-5 h-5" />
            {t('kitchen.startOrder')}
          </button>
        )}

        {status === 'preparing' && onComplete && (
          <button
            onClick={onComplete}
            className="w-full py-3 bg-green-600 hover:bg-green-500 rounded-xl font-bold flex items-center justify-center gap-2"
          >
            <CheckCircle className="w-5 h-5" />
            {t('kitchen.completeAll')}
          </button>
        )}

        {status === 'ready' && onServe && (
          <button
            onClick={onServe}
            className="w-full py-3 bg-white text-green-700 hover:bg-green-100 rounded-xl font-bold flex items-center justify-center gap-2"
          >
            <Bell className="w-5 h-5" />
            {t('kitchen.serveOrder')}
          </button>
        )}
      </div>
    </div>
  );
}
