// =============================================
// ORDER BUSINESS - DATABASE TYPES
// Supabase Schema - Customer App ile %100 uyumlu
// =============================================

export type Database = {
  public: {
    Tables: {
      venues: {
        Row: Venue;
        Insert: Omit<Venue, 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Venue, 'id'>>;
      };
      tables: {
        Row: Table;
        Insert: Omit<Table, 'id' | 'created_at'>;
        Update: Partial<Omit<Table, 'id'>>;
      };
      categories: {
        Row: Category;
        Insert: Omit<Category, 'id' | 'created_at'>;
        Update: Partial<Omit<Category, 'id'>>;
      };
      products: {
        Row: Product;
        Insert: Omit<Product, 'id' | 'created_at'>;
        Update: Partial<Omit<Product, 'id'>>;
      };
      orders: {
        Row: Order;
        Insert: Omit<Order, 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Order, 'id'>>;
      };
      order_items: {
        Row: OrderItem;
        Insert: Omit<OrderItem, 'id'>;
        Update: Partial<Omit<OrderItem, 'id'>>;
      };
      reservations: {
        Row: Reservation;
        Insert: Omit<Reservation, 'id' | 'created_at'>;
        Update: Partial<Omit<Reservation, 'id'>>;
      };
      staff: {
        Row: Staff;
        Insert: Omit<Staff, 'id' | 'created_at'>;
        Update: Partial<Omit<Staff, 'id'>>;
      };
      customers: {
        Row: Customer;
        Insert: Omit<Customer, 'id' | 'created_at'>;
        Update: Partial<Omit<Customer, 'id'>>;
      };
      stock_items: {
        Row: StockItem;
        Insert: Omit<StockItem, 'id' | 'created_at'>;
        Update: Partial<Omit<StockItem, 'id'>>;
      };
      coupons: {
        Row: Coupon;
        Insert: Omit<Coupon, 'id' | 'created_at'>;
        Update: Partial<Omit<Coupon, 'id'>>;
      };
      shifts: {
        Row: Shift;
        Insert: Omit<Shift, 'id' | 'created_at'>;
        Update: Partial<Omit<Shift, 'id'>>;
      };
      user_venues: {
        Row: UserVenue;
        Insert: Omit<UserVenue, 'id' | 'created_at'>;
        Update: Partial<Omit<UserVenue, 'id'>>;
      };
    };
  };
};

// =============================================
// VENUE (Mekan)
// =============================================
export interface Venue {
  id: string;
  name: string;
  slug: string;
  type: VenueType;
  address: string;
  city: string;
  district: string;
  phone: string;
  email: string;
  logo_url?: string;
  cover_url?: string;
  currency: string;
  timezone: string;
  is_active: boolean;
  settings: VenueSettings;
  created_at: string;
  updated_at: string;
}

export type VenueType = 'restaurant' | 'cafe' | 'bar' | 'beach_club' | 'nightclub' | 'hotel_restaurant';

export interface VenueSettings {
  working_hours?: WorkingHours;
  reservation_enabled?: boolean;
  qr_menu_enabled?: boolean;
  online_ordering_enabled?: boolean;
  min_order_amount?: number;
  service_charge_percent?: number;
  tax_rate?: number;
  auto_accept_orders?: boolean;
  notification_sounds?: boolean;
  theme_color?: string;
}

export interface WorkingHours {
  monday?: DayHours;
  tuesday?: DayHours;
  wednesday?: DayHours;
  thursday?: DayHours;
  friday?: DayHours;
  saturday?: DayHours;
  sunday?: DayHours;
}

export interface DayHours {
  is_open: boolean;
  open: string;
  close: string;
}

// =============================================
// TABLE (Masa) - Customer ile %100 uyumlu
// =============================================
export interface Table {
  id: string;
  venue_id: string;
  number: string;
  name?: string;
  capacity: number;
  section?: string;
  status: TableStatus;
  shape: TableShape;
  position_x?: number;
  position_y?: number;
  is_active: boolean;
  current_order_id?: string;
  created_at?: string;
}

export type TableStatus = 'available' | 'occupied' | 'reserved' | 'cleaning';
export type TableShape = 'square' | 'round' | 'rectangle';

// =============================================
// CATEGORY (Kategori)
// =============================================
export interface Category {
  id: string;
  venue_id: string;
  name: string;
  description?: string;
  image_url?: string;
  sort_order: number;
  is_active: boolean;
  created_at?: string;
}

// =============================================
// PRODUCT (Ürün)
// =============================================
export interface Product {
  id: string;
  venue_id: string;
  category_id: string;
  name: string;
  description?: string;
  price: number;
  image_url?: string;
  is_available: boolean;
  preparation_time?: number;
  allergens?: string[];
  options?: ProductOption[];
  sort_order: number;
  created_at?: string;
}

export interface ProductOption {
  id: string;
  name: string;
  choices: ProductOptionChoice[];
  is_required: boolean;
  max_selections: number;
}

export interface ProductOptionChoice {
  id: string;
  name: string;
  price_modifier: number;
}

// =============================================
// ORDER (Sipariş) - Customer ile %100 uyumlu
// items JSON olarak saklanıyor!
// =============================================
export interface Order {
  id: string;
  venue_id: string;
  table_id?: string;
  table_number?: string;
  customer_id?: string;
  order_number: string;
  type: OrderType;
  status: OrderStatus;
  items: OrderItemJSON[]; // JSON array olarak saklanıyor
  subtotal: number;
  tax: number;
  service_charge: number;
  discount: number;
  total: number;
  payment_status: PaymentStatus;
  payment_method?: PaymentMethod;
  notes?: string;
  waiter_id?: string;
  waiter_name?: string;
  created_at: string;
  updated_at: string;
}

// Order items JSON formatı (Supabase JSONB)
export interface OrderItemJSON {
  id: string;
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  options?: SelectedOption[];
  notes?: string;
  status: OrderItemStatus;
}

export type OrderType = 'dine_in' | 'takeaway' | 'delivery' | 'qr_order';
export type OrderStatus = 'pending' | 'confirmed' | 'preparing' | 'ready' | 'served' | 'completed' | 'cancelled';
export type PaymentStatus = 'pending' | 'partial' | 'paid' | 'refunded';
export type PaymentMethod = 'cash' | 'card' | 'tit_pay' | 'multinet' | 'sodexo' | 'ticket' | 'mobile' | 'mixed';
export type OrderItemStatus = 'pending' | 'preparing' | 'ready' | 'served' | 'cancelled';

export interface SelectedOption {
  option_name: string;
  choice_name: string;
  price_modifier: number;
}

// Ayrı tablo olarak order_items (opsiyonel - bazı sorgular için)
export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  options?: SelectedOption[];
  notes?: string;
  status: OrderItemStatus;
}

// =============================================
// RESERVATION (Rezervasyon)
// =============================================
export interface Reservation {
  id: string;
  venue_id: string;
  customer_id?: string;
  customer_name: string;
  customer_phone: string;
  customer_email?: string;
  date: string;
  time: string;
  party_size: number;
  table_ids?: string[];
  status: ReservationStatus;
  deposit_amount?: number;
  deposit_paid: boolean;
  notes?: string;
  special_requests?: string;
  created_at: string;
}

export type ReservationStatus = 'pending' | 'confirmed' | 'seated' | 'completed' | 'cancelled' | 'no_show';

// =============================================
// STAFF (Personel)
// =============================================
export interface Staff {
  id: string;
  venue_id: string;
  user_id?: string;
  name: string;
  role: StaffRole;
  phone?: string;
  email?: string;
  hourly_rate?: number;
  is_active: boolean;
  pin_code?: string;
  avatar_url?: string;
  created_at?: string;
}

export type StaffRole = 'owner' | 'manager' | 'cashier' | 'waiter' | 'kitchen' | 'reception';

// =============================================
// SHIFT (Vardiya)
// =============================================
export interface Shift {
  id: string;
  venue_id: string;
  staff_id: string;
  staff?: Staff;
  date: string;
  start_time: string;
  end_time: string;
  actual_start?: string;
  actual_end?: string;
  break_minutes: number;
  notes?: string;
  status: ShiftStatus;
  created_at?: string;
}

export type ShiftStatus = 'scheduled' | 'in_progress' | 'completed' | 'missed';

// =============================================
// CUSTOMER (Müşteri - CRM)
// =============================================
export interface Customer {
  id: string;
  venue_id: string;
  name: string;
  phone: string;
  email?: string;
  total_visits: number;
  total_spent: number;
  last_visit?: string;
  tags?: string[];
  notes?: string;
  is_vip: boolean;
  created_at: string;
}

// =============================================
// STOCK (Stok)
// =============================================
export interface StockItem {
  id: string;
  venue_id: string;
  name: string;
  unit: string;
  current_quantity: number;
  min_quantity: number;
  max_quantity?: number;
  cost_per_unit: number;
  supplier_id?: string;
  category: string;
  last_restocked?: string;
  created_at?: string;
}

// =============================================
// COUPON (Kupon)
// =============================================
export interface Coupon {
  id: string;
  venue_id: string;
  code: string;
  name: string;
  type: CouponType;
  value: number;
  min_order_amount?: number;
  max_uses?: number;
  used_count: number;
  valid_from: string;
  valid_until: string;
  is_active: boolean;
  created_at?: string;
}

export type CouponType = 'percentage' | 'fixed' | 'free_item';

// =============================================
// USER VENUE (Kullanıcı-Mekan İlişkisi)
// =============================================
export interface UserVenue {
  id: string;
  user_id: string;
  venue_id: string;
  role: StaffRole;
  permissions: Permission[];
  is_default: boolean;
  created_at: string;
}

export type Permission =
  | 'view_dashboard'
  | 'manage_orders'
  | 'manage_tables'
  | 'manage_menu'
  | 'manage_reservations'
  | 'manage_stock'
  | 'manage_staff'
  | 'view_reports'
  | 'manage_settings'
  | 'manage_pos'
  | 'manage_coupons';

// =============================================
// DASHBOARD & ALERTS
// =============================================
export interface VenueSummary {
  venue_id: string;
  venue_name: string;
  today_revenue: number;
  today_orders: number;
  active_orders: number;
  pending_reservations: number;
  low_stock_items: number;
  staff_on_duty: number;
  occupancy_rate: number;
}

export interface VenueAlert {
  id: string;
  venue_id: string;
  venue_name: string;
  type: 'order' | 'reservation' | 'stock' | 'staff' | 'system';
  severity: 'info' | 'warning' | 'error';
  message: string;
  created_at: string;
  is_read: boolean;
}

// =============================================
// NOTIFICATION
// =============================================
export interface Notification {
  id: string;
  venue_id: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, any>;
  is_read: boolean;
  created_at: string;
}

export type NotificationType =
  | 'new_order'
  | 'order_ready'
  | 'new_reservation'
  | 'low_stock'
  | 'shift_reminder'
  | 'payment_received'
  | 'waiter_call'
  | 'system';
